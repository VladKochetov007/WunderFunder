# R4 fit-controller amendment for the R3-profile cohort

R4 consumes the four raw R3 profile outputs at the existing paths
`runs/<cell>/profile/profile_receipt.json`. ROOT's fit admission binds each raw
receipt hash and GPU UUID. The controller first validates every raw receipt and
the measured contention receipt, then writes a separate ROOT-approved copy under
`receipts/approved-profiles-r4/<cell>.json`. Each copy sets `approved=true` and
records the ROOT admission SHA plus the untouched raw receipt SHA. Raw profile
receipts are never edited. `train_sequence.py` receives only the approved copy,
which preserves the exact original identity and profile evidence.

R4 runs under `/data2/lc-epanov_s/tabdata-all-followups-20261112-r1`, writes its
own controller state under `control/root-fits-r4/`, and writes its dispatch
receipt to `receipts/first-fit-r4.json`. Fit outputs remain at the canonical
`runs/<cell>/fit/` paths. It reads the R2 source/config/data/clock contracts,
`ROOT-fit-admission-r2.json`, and the measured R2 contention receipt. ROOT must
have copied the source capsule manifest to `source-r2/SOURCE_MANIFEST.json` and
reviewed the exact R3 profile receipts before authorizing fit admission.

Invoke only after the four profile receipts, contention evidence and ROOT fit
admission are complete:

```bash
PY=/tmp/tabdata-lc-epanov_s-architecture-20261107-env/bin/python
$PY /data2/lc-epanov_s/tabdata-all-followups-20261112-r1/control/r4-fit/root_fits_r4.py \
  --detach --admission-sha <ROOT_FIT_ADMISSION_SHA256>
```

The R2 fixed E6 contract and all-epoch official-valid checks are retained. The
R4 post-fit validator checks the six retained epoch checkpoints and six complete
monitor events, official validation membership/mask, train-eval coverage/mask,
fixed report-only E6 selection, and since-age empty-bucket semantics.
