from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

import pytest

RECEIVER = Path(__file__).with_name("root_fits_r4.py")
SOURCE_ROOT = Path(os.environ["WNN_SEQUENCE_SOURCE_ROOT"])
sys.path.insert(0, str(RECEIVER.parent))
sys.path.insert(0, str(SOURCE_ROOT / "src"))
from root_fits_r4 import build_train_command, create_root_approved_profile_copy
from wnn.training.sequence_profile_receipt import validate_profile_receipt


def _profile(approved: bool) -> tuple[dict[str, object], dict[str, object]]:
    identity: dict[str, object] = {
        "world_size": 1,
        "model_parameters": {"total": 2, "trainable": 2},
    }
    receipt: dict[str, object] = {
        "receipt_schema": "wnn.sequence-profile.v1",
        "status": "profile_complete",
        "approved": approved,
        "identity": identity,
        "updates": 30,
        "forwarded_rows": 30,
        "real_rows": 30,
        "valid_rows": 1,
        "epochs_traversed": 0,
        "elapsed_seconds": 1.0,
        "scientific_checkpoint_written": False,
        "errors": [],
        "error_count": 0,
        "losses": {"label": 1.0, "distillation": 0.0, "hint": 0.0, "total": 1.0},
        "model_parameters": {"total": 2, "trainable": 2},
        "memory_by_rank": [{
            "rank": 0,
            "peak_allocated_bytes": 100,
            "peak_reserved_bytes": 200,
            "device_total_memory_bytes": 1000,
            "host_peak_rss_bytes": 300,
        }],
        "peak_memory_bytes": 100,
        "peak_reserved_bytes": 200,
    }
    return identity, receipt


def _write_json(path: Path, value: object, *, replace: bool = False) -> None:
    import json
    if path.exists() and not replace:
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def test_real_trainer_argv_and_receipt_validator_use_admission_copy(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import hashlib
    import json

    identity, raw = _profile(approved=False)
    raw_path = tmp_path / "raw-profile.json"
    approved_path = tmp_path / "approved-profile.json"
    raw_path.write_text(json.dumps(raw), encoding="utf-8")
    raw_sha = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    admission_sha = "a" * 64
    got_raw_sha, approved_sha = create_root_approved_profile_copy(
        raw_path, approved_path, raw_sha, admission_sha, _write_json
    )
    assert got_raw_sha == raw_sha
    assert hashlib.sha256(approved_path.read_bytes()).hexdigest() == approved_sha
    assert json.loads(raw_path.read_text())["approved"] is False
    approved = json.loads(approved_path.read_text())
    assert approved["root_fit_approval"]["fit_admission_sha256"] == admission_sha
    assert approved["root_fit_approval"]["raw_profile_receipt_sha256"] == raw_sha
    assert approved["identity"] == identity

    # Call the repository's actual trainer receipt validator on both versions.
    assert validate_profile_receipt(approved_path, identity) == approved_sha
    with pytest.raises(ValueError, match="explicitly approved"):
        validate_profile_receipt(raw_path, identity)

    # Parse the exact R4-built train_sequence argv through its real argparse parser.
    config = tmp_path / "config.json"
    output = tmp_path / "fit-output"
    argv = build_train_command(config, output, approved_path)
    script = SOURCE_ROOT / "scripts/train_sequence.py"
    spec = importlib.util.spec_from_file_location("actual_train_sequence", script)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    training_stub = ModuleType("wnn.training.sequence_fit")
    training_stub.run_sequence_fit = lambda **_kwargs: None
    monkeypatch.setitem(sys.modules, "wnn.training.sequence_fit", training_stub)
    spec.loader.exec_module(module)
    parsed = module.build_parser().parse_args(argv[2:])
    assert parsed.profile_receipt == approved_path
