"""Bounded CPU fixtures for QK receiver identity, clock and telemetry gates."""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import b300_driver_core_r1 as legacy
import b300_qknorm_core_r1 as core
from b300_qknorm_compare_r1 import _panel_module, runtime_without_device_uuids
from b300_qknorm_fits_r1 import _verify_online_receipts
from b300_qknorm_postfit_waiter_r1 import _fit_terminal


class ReceiverGateTests(unittest.TestCase):
    """Exercise pure receipt gates without importing a model or touching CUDA."""

    def test_r2_clock_preserves_first_event_and_4h_plus_1h_window(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            first = 1_000.0
            (root / "first-profile-r1.json").write_text(
                json.dumps({"first_profile_epoch": first}), encoding="utf-8"
            )
            clock = root / "clock-r2.json"
            clock.write_text(
                json.dumps(
                    {
                        "first_profile_epoch": first,
                        "fit_deadline_epoch": first + 14_400,
                        "wave_deadline_epoch": first + 18_000,
                    }
                ),
                encoding="utf-8",
            )
            self.assertEqual(
                core.validate_clock(clock), (first, first + 14_400, first + 18_000)
            )
            clock.write_text(
                json.dumps(
                    {
                        "first_profile_epoch": first + 10,
                        "fit_deadline_epoch": first + 14_410,
                        "wave_deadline_epoch": first + 18_010,
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "preserve the original"):
                core.validate_clock(clock)

    def test_runtime_gate_masks_only_authority_bound_uuid(self) -> None:
        first = {
            "python": "3.12",
            "torch": "2.14",
            "cuda_runtime": "13.0",
            "precision": {"mode": "bf16_bf16x9"},
            "devices": [
                {
                    "rank": 0,
                    "name": "NVIDIA B300",
                    "capability": [12, 0],
                    "uuid": "uuid-a",
                    "total_memory_bytes": 300,
                },
                {
                    "rank": 1,
                    "name": "NVIDIA B300",
                    "capability": [12, 0],
                    "uuid": "uuid-b",
                    "total_memory_bytes": 300,
                },
            ],
        }
        second = json.loads(json.dumps(first))
        second["devices"][0]["uuid"] = "uuid-c"
        second["devices"][1]["uuid"] = "uuid-d"
        left = runtime_without_device_uuids(first, ["uuid-a", "uuid-b"])
        right = runtime_without_device_uuids(second, ["uuid-c", "uuid-d"])
        self.assertEqual(legacy.canonical_sha256(left), legacy.canonical_sha256(right))
        second["precision"]["mode"] = "bf16"
        changed = runtime_without_device_uuids(second, ["uuid-c", "uuid-d"])
        self.assertNotEqual(
            legacy.canonical_sha256(left), legacy.canonical_sha256(changed)
        )
        with self.assertRaisesRegex(ValueError, "UUID"):
            runtime_without_device_uuids(first, ["foreign", "uuid-b"])

    def test_online_heartbeat_and_delta_weight_receipts(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)
            (output / "monitor_progress.json").write_text(
                json.dumps({"phase": "completed", "step": core.FIT_UPDATES}),
                encoding="utf-8",
            )
            for rank in (0, 1):
                rows: list[dict[str, Any]] = []
                for step in range(1, core.FIT_UPDATES + 1):
                    row: dict[str, Any] = {"step": step}
                    if step % 50 == 0:
                        row["optimizer_update_diagnostics"] = {
                            "sampled_update_step": step,
                            "sampling_interval": 50,
                            "groups": {
                                "muon": {
                                    "pre_weight_norm": 2.0,
                                    "delta_weight_norm": 0.1,
                                    "delta_weight_rms": 0.01,
                                    "delta_weight_over_pre_weight_norm": 0.05,
                                }
                            },
                        }
                    rows.append(row)
                (output / f"rank{rank}.jsonl").write_text(
                    "".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8"
                )
            receipt = _verify_online_receipts(output)
            self.assertEqual(
                receipt["diagnostic_events_per_rank"], {"rank0": 65, "rank1": 65}
            )
            (output / "rank1.jsonl").write_text("{}\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "all 50-step"):
                _verify_online_receipts(output)

    def test_fit_admission_binds_all_four_profile_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "source-r1").mkdir()
            configs = {}
            entries = {}
            for cell in core.CELLS:
                cfg = {
                    "config_sha256": f"config-{cell}",
                    "raw_sha256": f"raw-{cell}",
                    "pair": core.PAIRS[cell],
                    "gpu_uuids": [f"{cell}-0", f"{cell}-1"],
                }
                configs[cell] = cfg
                entry = {
                    "config_sha256": cfg["config_sha256"],
                    "raw_config_sha256": cfg["raw_sha256"],
                    "pair": cfg["pair"],
                    "gpu_uuids": cfg["gpu_uuids"],
                }
                for receipt_name, path in (
                    (
                        "production_receipt",
                        root / "runs" / cell / "profile" / "profile_receipt.json",
                    ),
                    (
                        "peak_receipt",
                        root / "runs" / cell / "profile-peak" / "profile_receipt.json",
                    ),
                    (
                        "approved_receipt",
                        root / "runs" / cell / "approved_profile.json",
                    ),
                ):
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(receipt_name + cell, encoding="utf-8")
                    entry[f"{receipt_name}_path"] = str(path)
                    entry[f"{receipt_name}_sha256"] = legacy.sha256_file(path)
                entries[cell] = entry
            authority = {"configs": configs}
            admission = {
                "schema": core.ADMISSION_SCHEMA,
                "approved": True,
                "max_fresh_fits": 4,
                "source_sha256": core.SOURCE_SHA256,
                "source_root": str(root / "source-r1"),
                "authority_sha256": "authority-sha",
                "split_sha256": core.SPLIT_SHA256,
                "profiles": entries,
            }
            path = root / "admission.json"
            path.write_text(json.dumps(admission), encoding="utf-8")
            digest = legacy.sha256_file(path)
            self.assertEqual(
                core.validate_admission(
                    path, digest, "authority-sha", root, authority, configs
                ),
                admission,
            )
            (
                root / "runs" / core.CELLS[0] / "profile" / "profile_receipt.json"
            ).write_text("changed", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "does not bind"):
                core.validate_admission(
                    path, digest, "authority-sha", root, authority, configs
                )

    def test_actual_prediction_producer_nested_identity_schema(self) -> None:
        """Use a captured producer; world/data identity belongs under provenance.identity."""
        fixture = Path(__file__).parent / "fixtures" / "pr74_prediction_producer.json"
        producer = json.loads(fixture.read_text(encoding="utf-8"))
        provenance = producer["provenance"]
        identity = provenance["identity"]
        self.assertNotIn("world_size", provenance)
        self.assertNotIn("data_sha256", provenance)
        self.assertIn("world_size", identity)
        self.assertIn("data_sha256", identity)
        runtime = identity["runtime"]
        expected = [device["uuid"] for device in runtime["devices"]]
        self.assertEqual(
            runtime_without_device_uuids(runtime, expected)["devices"][0]["uuid"], None
        )
        source_value = os.environ.get("WNN_QK_SOURCE")
        if not source_value:
            self.skipTest(
                "set WNN_QK_SOURCE to exercise the pinned canonical producer validator"
            )
        panel = _panel_module(Path(source_value))
        panel.validate_producer(producer, core.SPLIT_SHA256, producer["fit_members"])
        self.assertEqual(panel.comparable_identity(producer)["world_size"], 2)

    def test_postfit_waiter_requires_complete_fit_and_owner_exit(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            control = root / "control" / "qknorm-receiver-r1"
            fit = control / "fit"
            fit.mkdir(parents=True)
            summary = {
                "status": "complete",
                "source_sha256": core.SOURCE_SHA256,
                "fits": {cell: {"status": "fit_complete"} for cell in core.CELLS},
            }
            owner = {"status": "complete", "owner": {"pid": 123, "birth_ticks": 456}}
            state = {"status": "complete"}
            (control / "fits-complete.json").write_text(
                json.dumps(summary), encoding="utf-8"
            )
            (fit / "owner.json").write_text(json.dumps(owner), encoding="utf-8")
            (fit / "status.json").write_text(json.dumps(state), encoding="utf-8")
            from unittest.mock import patch

            with patch(
                "b300_qknorm_postfit_waiter_r1.legacy.proc_entry",
                return_value=SimpleNamespace(start_ticks=456),
            ):
                self.assertIsNone(_fit_terminal(root))
            with patch(
                "b300_qknorm_postfit_waiter_r1.legacy.proc_entry", return_value=None
            ):
                result = _fit_terminal(root)
            self.assertEqual(result[0]["status"], "complete")


if __name__ == "__main__":
    unittest.main()
