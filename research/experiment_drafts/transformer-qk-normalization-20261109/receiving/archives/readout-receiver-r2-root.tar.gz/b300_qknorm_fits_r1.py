"""Run the four ROOT-admitted PR75 fixed-4E QK-normalization fits."""

from __future__ import annotations

import json
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_driver_fits_r1 as fit_checks
import b300_driver_support_r1 as support
import b300_owned_runner_r2 as runner
import b300_qknorm_core_r1 as core

support.run_owned = runner.run_owned
_base_environment = support._environment


def _environment(source: Path, root: Path, uuids: list[str]) -> dict[str, str]:
    """Enable the canonical ten-second monitor heartbeat in every fit worker."""
    env = _base_environment(source, root, uuids)
    env["WNN_MONITOR_HEARTBEAT_SECONDS"] = "10"
    return env


support._environment = _environment


def _verify_online_receipts(output: Path) -> dict[str, Any]:
    """Require ten-second monitor publication and real sampled Delta-W on both ranks."""
    progress = legacy.read_json(output / "monitor_progress.json", 32_000)
    if progress.get("phase") != "completed" or progress.get("step") != core.FIT_UPDATES:
        raise ValueError("fit lacks final canonical monitor-progress heartbeat")
    observed: dict[str, int] = {}
    for rank in (0, 1):
        path = output / f"rank{rank}.jsonl"
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 64_000_000:
            raise ValueError(f"rank {rank} update log is missing or oversized")
        raw = path.read_bytes()
        if raw and not raw.endswith(b"\n"):
            raise ValueError(f"rank {rank} update log ends in a partial record")
        records = [json.loads(line) for line in raw.splitlines()]
        sampled = [
            record for record in records if "optimizer_update_diagnostics" in record
        ]
        if len(sampled) != core.FIT_UPDATES // 50:
            raise ValueError(
                f"rank {rank} does not contain all 50-step optimizer diagnostics"
            )
        for record in sampled:
            step = record.get("step")
            diag = record["optimizer_update_diagnostics"]
            if (
                type(step) is not int
                or step % 50 != 0
                or diag.get("sampled_update_step") != step
                or diag.get("sampling_interval") != 50
                or not isinstance(diag.get("groups"), dict)
                or not diag["groups"]
            ):
                raise ValueError(f"rank {rank} sampled diagnostic identity is invalid")
            for group in diag["groups"].values():
                for key in (
                    "pre_weight_norm",
                    "delta_weight_norm",
                    "delta_weight_rms",
                    "delta_weight_over_pre_weight_norm",
                ):
                    value = group.get(key)
                    if (
                        not isinstance(value, (int, float))
                        or isinstance(value, bool)
                        or not math.isfinite(float(value))
                        or value < 0
                    ):
                        raise ValueError(f"rank {rank} Delta-W field {key} is invalid")
        observed[f"rank{rank}"] = len(sampled)
    return {
        "monitor_progress_sha256": legacy.sha256_file(output / "monitor_progress.json"),
        "diagnostic_events_per_rank": observed,
        "diagnostic_interval": 50,
    }


def _run_acceptance(
    *,
    python: Path,
    source: Path,
    root: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    cell: str,
    deadline: float,
    state_path: Path,
    state_lock: threading.Lock,
) -> None:
    """Re-run the exact PR75 profile approval checker immediately before launch."""
    packet = source / "research/experiment_drafts/transformer-qk-normalization-20261109"
    command = [
        str(python),
        str(packet / "acceptance.py"),
        "--mode",
        "profiles",
        "--root",
        str(root),
        "--commit",
        core.COMMIT,
        "--split",
        str(split),
        "--data-root",
        str(data_root),
        "--cell",
        cell,
    ]
    result = support._run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell=cell,
        stage="acceptance-profiles",
        output=root,
        command=command,
        gpu_uuids=[],
        deadline=deadline,
        timeout=900,
        state_path=state_path,
        state_lock=state_lock,
    )
    if result.get("status") != "completed":
        raise runner.OwnedRunError(f"PR75 profile approval check failed for {cell}")


def _fit_cell(
    *,
    cell: str,
    item: dict[str, Any],
    admission: dict[str, Any],
    config: dict[str, Any],
    config_sha: str,
    source_files: dict[str, str],
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    deadline: float,
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Run one new fixed endpoint; a pre-existing output is a hard no-retry failure."""
    result_path = control / "fits" / f"{cell}.json"
    output = root / "runs" / cell / "fit"
    try:
        if (
            result_path.exists()
            or result_path.is_symlink()
            or output.exists()
            or output.is_symlink()
        ):
            raise FileExistsError(
                f"fit output already exists for {cell}; resume/retry disabled"
            )
        _run_acceptance(
            python=python,
            source=source,
            root=root,
            data_root=data_root,
            split=split,
            control=control,
            guard=guard,
            owner=owner,
            cell=cell,
            deadline=deadline,
            state_path=state_path,
            state_lock=state_lock,
        )
        uuids = [str(value).removeprefix("GPU-") for value in item["gpu_uuids"]]
        command = [
            str(python),
            "-m",
            "torch.distributed.run",
            "--standalone",
            "--nnodes=1",
            "--nproc-per-node=2",
            str(source / "scripts/train_sequence.py"),
            "--config",
            str(item["path"]),
            "--data-root",
            str(data_root),
            "--split-manifest",
            str(split),
            "--output",
            str(output),
            "--profile-receipt",
            str(root / "runs" / cell / "approved_profile.json"),
        ]
        timeout = max(1, int(deadline - time.time()))
        owned = support._run_stage(
            python=python,
            source=source,
            root=root,
            control=control,
            guard=guard,
            owner=owner,
            cell=cell,
            stage="fit",
            output=output,
            command=command,
            gpu_uuids=uuids,
            deadline=deadline,
            timeout=timeout,
            state_path=state_path,
            state_lock=state_lock,
        )
        if owned.get("status") != "completed":
            raise runner.OwnedRunError(f"canonical fit process failed for {cell}")
        evidence = fit_checks._fit_metrics(
            root, cell, config, config_sha, core.SOURCE_SHA256, uuids
        )
        online = _verify_online_receipts(output)
        result = {
            "schema": "wnn.b300-qknorm-fit-cell.r1",
            "cell": cell,
            "status": "fit_complete",
            "source_commit": core.COMMIT,
            "source_sha256": core.SOURCE_SHA256,
            "authority_sha256": legacy.sha256_file(control / "authority.json"),
            "fit_admission_sha256": legacy.sha256_file(
                control / "ROOT-fit-admission-r1.json"
            ),
            "config_sha256": config_sha,
            "raw_config_sha256": item["raw_sha256"],
            "pair": item["pair"],
            "gpu_uuids": uuids,
            "fixed_epochs": 4,
            "global_updates": core.FIT_UPDATES,
            "fit_members": core.FIT_MEMBERS,
            "evaluation_members": core.VALID_MEMBERS,
            "scored_rows": core.SCORED_ROWS,
            "owned_fit": owned,
            "model_sha256": evidence["model_sha256"],
            "terminal_sha256": evidence["terminal_sha256"],
            "metadata_sha256": evidence["metadata_sha256"],
            "monitor_sha256": evidence["monitor_sha256"],
            "data_sha256": evidence["data_sha256"],
            "final_metrics": evidence["final_metrics"],
            "epoch_metrics": evidence["epoch_metrics"],
            "online_receipts": online,
            "profile_approval_sha256": admission[cell]["approved_receipt_sha256"],
            "completed_epoch": time.time(),
            "automatic_resume": False,
            "automatic_retry": False,
        }
    except Exception as error:  # noqa: BLE001 - save every cell's terminal state.
        result = {
            "schema": "wnn.b300-qknorm-fit-cell.r1",
            "cell": cell,
            "status": "fit_failed_or_partial",
            "error": f"{type(error).__name__}: {error}",
            "source_sha256": core.SOURCE_SHA256,
            "config_sha256": config_sha,
            "automatic_resume": False,
            "automatic_retry": False,
            "observed_epoch": time.time(),
        }
    legacy.atomic_json(result_path, result)
    return result


def run_fits(
    *,
    authority: dict[str, Any],
    configs: dict[str, dict[str, Any]],
    values: dict[str, dict[str, Any]],
    config_shas: dict[str, str],
    source_files: dict[str, str],
    authority_sha: str,
    admission_path: Path,
    admission_sha: str,
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Validate ROOT release before each of the four independent two-GPU fit streams."""
    first, fit_deadline, wave_deadline = core.validate_clock(
        Path(authority["clock_path"]), authority
    )
    if time.time() >= fit_deadline:
        raise TimeoutError("original four-hour fit deadline has closed")
    profiles = legacy.read_json(control / "profiles-complete.json", 1_000_000)
    if profiles.get("status") != "profiles_complete" or set(
        profiles.get("cells", {})
    ) != set(core.CELLS):
        raise ValueError("all four 50-update profiles must complete before fitting")
    core.verify_data_check(root / "data-check.json", data_root, split)
    core.validate_admission(
        admission_path, admission_sha, authority_sha, root, authority, configs
    )
    result_path = control / "fits-complete.json"
    if result_path.exists() or result_path.is_symlink():
        raise FileExistsError("fit completion receipt exists; no automatic restart")

    def run_one(cell: str) -> dict[str, Any]:
        if time.time() >= fit_deadline:
            raise TimeoutError(
                "original five-hour fit deadline reached before cell launch"
            )
        # Re-read all four approvals before every fit so revocation/change stops admission.
        current = core.validate_admission(
            admission_path, admission_sha, authority_sha, root, authority, configs
        )
        return _fit_cell(
            cell=cell,
            item=configs[cell],
            admission=current["profiles"],
            config=values[cell],
            config_sha=config_shas[cell],
            source_files=source_files,
            root=root,
            source=source,
            python=python,
            data_root=data_root,
            split=split,
            control=control,
            guard=guard,
            owner=owner,
            deadline=fit_deadline,
            state_path=state_path,
            state_lock=state_lock,
        )

    outcomes: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix="qk-fit-pair") as pool:
        futures = {pool.submit(run_one, cell): cell for cell in core.CELLS}
        for future in as_completed(futures):
            cell = futures[future]
            try:
                outcomes[cell] = future.result()
            except Exception as error:  # noqa: BLE001 - persist a failed stream.
                outcomes[cell] = {
                    "schema": "wnn.b300-qknorm-fit-cell.r1",
                    "cell": cell,
                    "status": "fit_controller_failed",
                    "error": f"{type(error).__name__}: {error}",
                    "automatic_resume": False,
                    "automatic_retry": False,
                }
            legacy.atomic_json(
                control / "fit-stream-status.json",
                {
                    "schema": "wnn.b300-qknorm-fit-stream-status.r1",
                    "fits": outcomes,
                    "updated_epoch": time.time(),
                },
                replace=True,
            )
    complete = set(outcomes) == set(core.CELLS) and all(
        result.get("status") == "fit_complete" for result in outcomes.values()
    )
    summary = {
        "schema": "wnn.b300-qknorm-fit-summary.r1",
        "status": "complete" if complete else "partial_or_failed",
        "source_sha256": core.SOURCE_SHA256,
        "source_commit": core.COMMIT,
        "authority_sha256": authority_sha,
        "fit_admission_sha256": admission_sha,
        "split_sha256": core.SPLIT_SHA256,
        "first_profile_epoch": first,
        "fit_deadline_epoch": fit_deadline,
        "wave_deadline_epoch": wave_deadline,
        "fits": outcomes,
        "automatic_resume": False,
        "automatic_retry": False,
        "fit_pair_streams": {
            "0,1": [core.CELLS[0]],
            "2,3": [core.CELLS[1]],
            "4,5": [core.CELLS[2]],
            "6,7": [core.CELLS[3]],
        },
    }
    legacy.atomic_json(result_path, summary)
    return summary
