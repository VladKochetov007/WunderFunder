"""ROOT-authorized PR75 QK-normalization B300 profile/fit receiver."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_driver_support_r1 as support
import b300_owned_runner_r2 as runner
import b300_qknorm_core_r1 as core

core.bind_legacy_contract()
support.run_owned = runner.run_owned

RECEIVER = Path(__file__).absolute().parent
CONTROL_NAME = "qknorm-receiver-r1"


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase", choices=("profiles", "fit", "readout"), required=True
    )
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--authority-sha256", required=True)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--manifest-sha256", default=core.MANIFEST_SHA256)
    parser.add_argument("--python", type=Path)
    parser.add_argument("--fit-admission", type=Path)
    parser.add_argument("--fit-admission-sha256")
    parser.add_argument("--detach", action="store_true")
    return parser


def _prepare(
    args: argparse.Namespace,
) -> tuple[
    dict[str, Any],
    dict[str, dict[str, Any]],
    dict[str, dict[str, Any]],
    dict[str, str],
    dict[str, str],
    Path,
    Path,
    Path,
    Path,
    Path,
    Path,
    Path,
]:
    """Bind immutable source, authority, configs and official split before any stage."""
    if os.name != "posix":
        raise RuntimeError("B300 receiving controller must run on ROOT-owned Linux")
    root = args.root.resolve(strict=True)
    authority_path = args.authority.resolve(strict=True)
    authority = core.read_authority(authority_path, args.authority_sha256, root)
    source = (args.source or Path(authority["source"]["source_root"])).resolve(
        strict=True
    )
    if source != root / "source-r1":
        raise ValueError(
            "source must be the isolated source-r1 capsule under native_root"
        )
    manifest = (args.manifest or Path(authority["source"]["manifest_path"])).resolve(
        strict=True
    )
    if (
        args.manifest_sha256 != core.MANIFEST_SHA256
        or authority["source"]["manifest_sha256"] != args.manifest_sha256
    ):
        raise ValueError("source manifest SHA differs from the frozen capsule")
    source_sha, files = legacy.verify_source_capsule(
        source, manifest, core.MANIFEST_SHA256, core.COMMIT
    )
    if (
        source_sha != core.SOURCE_SHA256
        or authority["source"]["source_sha256"] != source_sha
    ):
        raise ValueError("derived canonical trainer identity differs from source pin")
    configs = authority["configs"]
    values, config_shas = core.verify_configs(source, configs)
    data_root, split = Path(authority["data_root"]), Path(authority["split"])
    if legacy.sha256_file(split) != core.SPLIT_SHA256:
        raise ValueError(
            "official chronological split bytes differ from the frozen SHA"
        )
    python = support._absolute_executable(args.python or Path(authority["python"]))
    control = root / "control" / CONTROL_NAME
    if control.is_symlink():
        raise ValueError("receiver control directory may not be a symlink")
    control.mkdir(parents=True, exist_ok=True)
    return (
        authority,
        configs,
        values,
        config_shas,
        legacy.source_identity_files(files),
        root,
        source,
        data_root,
        split,
        python,
        control,
        authority_path,
    )


def _detach(args: argparse.Namespace) -> dict[str, Any]:
    """Launch one detached receiver phase and publish its controller birth identity."""
    root = args.root.resolve(strict=True)
    control = root / "control" / CONTROL_NAME / "detached"
    control.mkdir(parents=True, exist_ok=True)
    owner_path = control / f"{args.phase}-owner.json"
    log_path = control / f"{args.phase}.log"
    if any(path.exists() or path.is_symlink() for path in (owner_path, log_path)):
        raise FileExistsError(
            "detached phase already has an owner/log; restart is disabled"
        )
    child_args = [arg for arg in sys.argv[1:] if arg != "--detach"]
    command = [
        str(args.python or sys.executable),
        "-u",
        str(RECEIVER / Path(__file__).name),
        *child_args,
    ]
    with log_path.open("xb") as stream:
        process = subprocess.Popen(
            command,
            cwd=root,
            stdin=subprocess.DEVNULL,
            stdout=stream,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
    child = None
    for _ in range(100):
        child = legacy.proc_entry(process.pid)
        if child is not None:
            break
        time.sleep(0.02)
    if child is None:
        raise RuntimeError("detached controller exited before birth could be recorded")
    value = {
        "schema": "wnn.b300-qknorm-detached-owner.r1",
        "phase": args.phase,
        "controller": {"pid": child.pid, "birth_ticks": child.start_ticks},
        "command": command,
        "log_path": str(log_path),
        "created_epoch": time.time(),
    }
    legacy.atomic_json(owner_path, value)
    return value


def _run(args: argparse.Namespace) -> int:
    if args.phase == "fit" and not args.fit_admission_sha256:
        raise ValueError("fit phase requires --fit-admission-sha256")
    (
        authority,
        configs,
        values,
        config_shas,
        source_files,
        root,
        source,
        data_root,
        split,
        python,
        control,
        authority_path,
    ) = _prepare(args)
    expected_admission = Path(authority["fit_admission_path"])
    admission = args.fit_admission or expected_admission
    if admission != expected_admission:
        raise ValueError("fit-admission path differs from the pinned ROOT authority")
    authority_copy = control / "authority.json"
    if authority_copy.exists() or authority_copy.is_symlink():
        if (
            authority_copy.is_symlink()
            or legacy.sha256_file(authority_copy) != args.authority_sha256
        ):
            raise ValueError("staged receiver authority already differs")
    else:
        shutil.copyfile(authority_path, authority_copy)
    lock_path = control / "phase.lock"
    import fcntl

    lock_stream = lock_path.open("a+b")
    try:
        fcntl.flock(lock_stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error:
        lock_stream.close()
        raise RuntimeError("another receiver phase owns the native run root") from error
    phase_root = control / args.phase
    phase_root.mkdir(exist_ok=True)
    owner_path = phase_root / "owner.json"
    state_path = phase_root / "status.json"
    if any(path.exists() or path.is_symlink() for path in (owner_path, state_path)):
        raise FileExistsError(
            f"{args.phase} phase already ran; automatic retries are disabled"
        )
    owner = support._identity(root)
    completed = time.time()
    legacy.atomic_json(
        owner_path,
        {
            "schema": "wnn.b300-qknorm-phase-owner.r1",
            "phase": args.phase,
            "owner": owner,
            "source_sha256": core.SOURCE_SHA256,
            "source_commit": core.COMMIT,
            "authority_sha256": args.authority_sha256,
            "fit_admission_sha256": args.fit_admission_sha256,
            "started_epoch": completed,
        },
    )
    legacy.atomic_json(
        state_path,
        {
            "schema": "wnn.b300-qknorm-phase-status.r1",
            "phase": args.phase,
            "status": "running",
            "owner": owner,
            "cells": {},
            "started_epoch": completed,
        },
    )
    state_lock = threading.Lock()
    guard = runner.ResourceGuard(root, control, support._caps(authority))
    try:
        if legacy.directory_bytes(root) > authority["budget"]["output_bytes"]:
            raise OSError("native output exceeds the authority cap")
        stat = os.statvfs(root)
        if stat.f_bavail * stat.f_frsize < authority["budget"]["minimum_free_bytes"]:
            raise OSError("native free space is below the authority reserve")
        if args.phase == "profiles":
            from b300_qknorm_profiles_r1 import run_profiles

            result = run_profiles(
                authority=authority,
                configs=configs,
                values=values,
                config_shas=config_shas,
                source_files=source_files,
                root=root,
                source=source,
                python=python,
                data_root=data_root,
                split=split,
                control=control,
                guard=guard,
                owner=owner,
                state_path=state_path,
                state_lock=state_lock,
            )
        elif args.phase == "fit":
            from b300_qknorm_fits_r1 import run_fits

            result = run_fits(
                authority=authority,
                configs=configs,
                values=values,
                config_shas=config_shas,
                source_files=source_files,
                authority_sha=args.authority_sha256,
                admission_path=admission,
                admission_sha=args.fit_admission_sha256,
                root=root,
                source=source,
                python=python,
                data_root=data_root,
                split=split,
                control=control,
                guard=guard,
                owner=owner,
                state_path=state_path,
                state_lock=state_lock,
            )
        else:
            raise NotImplementedError(
                "readout phase is being added as a separate receiver module"
            )
    except Exception as error:
        failed_at = time.time()
        state = legacy.read_json(state_path, 4_000_000)
        state.update(
            status="failed",
            error=f"{type(error).__name__}: {error}",
            completed_epoch=failed_at,
        )
        legacy.atomic_json(state_path, state, replace=True)
        phase_owner = legacy.read_json(owner_path, 64_000)
        phase_owner.update(
            status="failed",
            error=f"{type(error).__name__}: {error}",
            completed_epoch=failed_at,
        )
        legacy.atomic_json(owner_path, phase_owner, replace=True)
        raise
    status = result.get("status", "failed")
    state = legacy.read_json(state_path, 4_000_000)
    state.update(status=status, summary=result, completed_epoch=time.time())
    legacy.atomic_json(state_path, state, replace=True)
    phase_owner = legacy.read_json(owner_path, 64_000)
    phase_owner.update(status=status, completed_epoch=state["completed_epoch"])
    legacy.atomic_json(owner_path, phase_owner, replace=True)
    print(json.dumps({"phase": args.phase, "status": status}, sort_keys=True))
    return 0 if status in ("profiles_complete", "complete") else 2


def main(argv: list[str] | None = None) -> int:
    """Run one explicit new profile or fit phase; no model resume or automatic retry."""
    args = _parser().parse_args(argv)
    if args.detach:
        print(json.dumps(_detach(args), sort_keys=True))
        return 0
    return _run(args)


if __name__ == "__main__":
    raise SystemExit(main())
