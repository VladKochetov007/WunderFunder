"""Bounded waiter that launches readout once the admitted four-fit owner exits."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_qknorm_core_r1 as core
import b300_qknorm_driver_r1 as fit_driver
import b300_qknorm_readout_driver_r1 as readout_driver

core.bind_legacy_contract()


def _fit_terminal(root: Path) -> tuple[dict[str, Any], dict[str, Any]] | None:
    """Return completed fit receipts only after the fit controller's birth has exited."""
    control = root / "control" / fit_driver.CONTROL_NAME
    summary_path = control / "fits-complete.json"
    owner_path = control / "fit" / "owner.json"
    state_path = control / "fit" / "status.json"
    if not all(
        path.is_file() and not path.is_symlink()
        for path in (summary_path, owner_path, state_path)
    ):
        return None
    summary = legacy.read_json(summary_path, 4_000_000)
    owner = legacy.read_json(owner_path, 64_000)
    state = legacy.read_json(state_path, 4_000_000)
    if (
        summary.get("status") != "complete"
        or owner.get("status") != "complete"
        or state.get("status") != "complete"
    ):
        raise RuntimeError(
            "fit phase ended partial/failed; waiter will not launch readout"
        )
    identity = owner.get("owner")
    if (
        not isinstance(identity, dict)
        or type(identity.get("pid")) is not int
        or type(identity.get("birth_ticks")) is not int
    ):
        raise ValueError("fit owner receipt lacks PID/birth identity")
    current = legacy.proc_entry(identity["pid"])
    if current is not None and current.start_ticks == identity["birth_ticks"]:
        return None
    return summary, owner


def main(argv: list[str] | None = None) -> int:
    """Wait no longer than the original 1h collection window, then run readout once."""
    parser = fit_driver._parser()
    parser.description = __doc__
    args = parser.parse_args(argv)
    if args.phase != "readout" or args.detach:
        parser.error(
            "postfit waiter requires --phase readout and runs under ROOT's owner"
        )
    if os.name != "posix":
        raise RuntimeError("postfit waiter must run on ROOT-owned Linux")
    import fcntl

    prepared = fit_driver._prepare(args)
    (
        authority,
        _configs,
        _values,
        _shas,
        _files,
        root,
        _source,
        _data,
        _split,
        _python,
        _control,
        _path,
    ) = prepared
    first, _fit_deadline, wave_deadline = core.validate_clock(
        Path(authority["clock_path"]), authority
    )
    control = root / "control" / fit_driver.CONTROL_NAME
    receipt_path = control / "postfit-waiter-r1.json"
    progress_path = control / "postfit-waiter-status-r1.json"
    if any(
        path.exists() or path.is_symlink() for path in (receipt_path, progress_path)
    ):
        raise FileExistsError(
            "postfit waiter receipt exists; automatic relaunch is disabled"
        )
    started = time.time()
    legacy.atomic_json(
        progress_path,
        {
            "schema": "wnn.b300-qknorm-postfit-waiter-status.r1",
            "status": "waiting_for_fits",
            "first_profile_epoch": first,
            "wave_deadline_epoch": wave_deadline,
            "started_epoch": started,
            "updated_epoch": started,
        },
    )
    while time.time() < wave_deadline:
        try:
            result = _fit_terminal(root)
        except Exception as error:  # noqa: BLE001 - terminally receipt unexpected gate failures.
            value = {
                "schema": "wnn.b300-qknorm-postfit-waiter.r1",
                "status": "fit_failed_or_partial",
                "first_profile_epoch": first,
                "wave_deadline_epoch": wave_deadline,
                "started_epoch": started,
                "error": f"{type(error).__name__}: {error}",
                "readout_started": False,
                "completed_epoch": time.time(),
            }
            legacy.atomic_json(receipt_path, value)
            legacy.atomic_json(progress_path, value, replace=True)
            return 2
        if result is not None:
            summary, owner = result
            if (
                summary.get("source_sha256") != core.SOURCE_SHA256
                or summary.get("authority_sha256") != args.authority_sha256
                or summary.get("split_sha256") != core.SPLIT_SHA256
            ):
                raise ValueError(
                    "fit completion receipt differs from the pinned source/authority/split"
                )
            lock_path = control / "phase.lock"
            lock_stream = lock_path.open("a+b")
            try:
                fcntl.flock(lock_stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                lock_stream.close()
                legacy.atomic_json(
                    progress_path,
                    {
                        "schema": "wnn.b300-qknorm-postfit-waiter-status.r1",
                        "status": "waiting_for_fit_owner_exit",
                        "first_profile_epoch": first,
                        "wave_deadline_epoch": wave_deadline,
                        "started_epoch": started,
                        "fit_owner": owner,
                        "updated_epoch": time.time(),
                    },
                    replace=True,
                )
                time.sleep(min(10.0, max(0.1, wave_deadline - time.time())))
                continue
            fcntl.flock(lock_stream.fileno(), fcntl.LOCK_UN)
            lock_stream.close()
            args_list = [
                "--phase",
                "readout",
                "--root",
                str(args.root),
                "--authority",
                str(args.authority),
                "--authority-sha256",
                args.authority_sha256,
                "--source",
                str(args.source or Path(authority["source"]["source_root"])),
                "--manifest",
                str(args.manifest or Path(authority["source"]["manifest_path"])),
                "--manifest-sha256",
                args.manifest_sha256,
                "--python",
                str(args.python or Path(authority["python"])),
            ]
            legacy.atomic_json(
                progress_path,
                {
                    "schema": "wnn.b300-qknorm-postfit-waiter-status.r1",
                    "status": "launching_readout",
                    "first_profile_epoch": first,
                    "wave_deadline_epoch": wave_deadline,
                    "started_epoch": started,
                    "fit_owner": owner,
                    "updated_epoch": time.time(),
                },
                replace=True,
            )
            try:
                code = readout_driver.main(args_list)
            except Exception as error:  # noqa: BLE001 - record readout failures before exit.
                value = {
                    "schema": "wnn.b300-qknorm-postfit-waiter.r1",
                    "status": "readout_failed",
                    "first_profile_epoch": first,
                    "wave_deadline_epoch": wave_deadline,
                    "started_epoch": started,
                    "fit_owner": owner,
                    "fit_summary_sha256": legacy.sha256_file(
                        control / "fits-complete.json"
                    ),
                    "error": f"{type(error).__name__}: {error}",
                    "completed_epoch": time.time(),
                }
                legacy.atomic_json(receipt_path, value)
                legacy.atomic_json(progress_path, value, replace=True)
                return 2
            value = {
                "schema": "wnn.b300-qknorm-postfit-waiter.r1",
                "status": "readout_complete" if code == 0 else "readout_failed",
                "first_profile_epoch": first,
                "wave_deadline_epoch": wave_deadline,
                "started_epoch": started,
                "fit_owner": owner,
                "fit_summary_sha256": legacy.sha256_file(
                    control / "fits-complete.json"
                ),
                "readout_exit_code": code,
                "completed_epoch": time.time(),
            }
            legacy.atomic_json(receipt_path, value)
            legacy.atomic_json(progress_path, value, replace=True)
            return code
        legacy.atomic_json(
            progress_path,
            {
                "schema": "wnn.b300-qknorm-postfit-waiter-status.r1",
                "status": "waiting_for_fits",
                "first_profile_epoch": first,
                "wave_deadline_epoch": wave_deadline,
                "started_epoch": started,
                "updated_epoch": time.time(),
            },
            replace=True,
        )
        time.sleep(min(10.0, max(0.1, wave_deadline - time.time())))
    value = {
        "schema": "wnn.b300-qknorm-postfit-waiter.r1",
        "status": "timed_out",
        "first_profile_epoch": first,
        "wave_deadline_epoch": wave_deadline,
        "started_epoch": started,
        "completed_epoch": time.time(),
        "readout_started": False,
    }
    legacy.atomic_json(receipt_path, value)
    legacy.atomic_json(progress_path, value, replace=True)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
