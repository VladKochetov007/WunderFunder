"""Grade four canonical PR75 scores under the explicit four-pair UUID amendment."""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

import b300_qknorm_core_r1 as core
from b300_driver_core_r1 import canonical_sha256, sha256_file


def runtime_without_device_uuids(
    runtime: dict[str, Any], expected: list[str]
) -> dict[str, Any]:
    """Permit only UUID changes; preserve software, precision, device class and capability."""
    value = copy.deepcopy(runtime)
    devices = value.get("devices")
    if not isinstance(devices, list) or len(devices) != 2:
        raise ValueError("runtime must identify exactly two rank-local B300 devices")
    uuids = []
    for rank, device in enumerate(devices):
        if not isinstance(device, dict) or device.get("rank") != rank:
            raise ValueError("runtime device rank order differs")
        uuid = str(device.get("uuid", "")).removeprefix("GPU-")
        if not uuid or uuid != expected[rank]:
            raise ValueError("runtime device UUID differs from its authority pair")
        if "B300" not in str(device.get("name", "")).upper():
            raise ValueError("runtime device is not identified as an NVIDIA B300")
        capability = device.get("capability")
        memory = device.get("total_memory_bytes")
        if (
            not isinstance(capability, list)
            or len(capability) != 2
            or any(type(item) is not int for item in capability)
            or not isinstance(memory, int)
            or memory <= 0
        ):
            raise ValueError(
                "runtime device class/capability/memory identity is incomplete"
            )
        uuids.append(uuid)
        device["uuid"] = None
    if len(set(uuids)) != 2:
        raise ValueError("runtime reused a device inside its rank pair")
    return value


def _panel_module(source: Path) -> Any:
    """Import the exact pinned comparison helpers without editing packet source."""
    source_path = str(source / "src")
    if source_path not in sys.path:
        sys.path.insert(0, source_path)
    packet = source / "research/experiment_drafts/transformer-qk-normalization-20261109"
    spec = importlib.util.spec_from_file_location(
        "pinned_qknorm_compare_panel", packet / "compare_panel.py"
    )
    if spec is None or spec.loader is None:
        raise ImportError("pinned PR75 comparison module is unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compare(
    root: Path,
    source: Path,
    data_root: Path,
    split_path: Path,
    authority: dict[str, Any],
) -> dict[str, Any]:
    """Validate exact canonical scores, then mask only authority-bound device UUIDs."""
    panel = _panel_module(source)
    from wnn.splits import load_campaign_split
    from wnn.training.sequence_config import load_config
    from wnn.training.sequence_provenance import source_identity

    split = load_campaign_split(split_path, data_root)
    if (
        split.sha256 != core.SPLIT_SHA256
        or split.valid_groups
        or len(split.train_groups) != core.FIT_MEMBERS
    ):
        raise ValueError("scorer split differs from exact train-only official boundary")
    fit_members = [("train", int(group)) for group in split.train_groups]
    expected_source = source_identity(source, source / "scripts/train_sequence.py")
    rows: dict[str, dict[str, Any]] = {}
    template_hashes, common_hashes = set(), set()
    seed_runtimes: dict[int, set[str]] = {203301: set(), 203302: set()}
    identity_hashes: dict[str, dict[str, str]] = {}
    for cell in core.CELLS:
        fit = root / "runs" / cell / "fit"
        terminal = panel.read(fit / "terminal_status.json")
        score = panel.grade(fit / "score.json")
        producer = score.get("producer")
        if not isinstance(producer, dict):
            raise TypeError(f"canonical score lacks its producer record: {cell}")
        panel.validate_producer(producer, core.SPLIT_SHA256, fit_members)
        checkpoint_sha = sha256_file(fit / "model.pt")
        config = load_config(Path(authority["configs"][cell]["path"]))
        recipe = json.loads(json.dumps(config))
        seed = core.SEEDS[cell]
        expected_norm = "rms" if cell.startswith("rms_") else "none"
        if (
            recipe.pop("seed") != seed
            or recipe["model"].pop("qk_norm", "none") != expected_norm
        ):
            raise ValueError(
                f"model/seed recipe differs from the frozen cell name: {cell}"
            )
        template_hashes.add(canonical_sha256(recipe))
        profile_path = root / "runs" / cell / "approved_profile.json"
        profile_sha = sha256_file(profile_path)
        identity = terminal.get("identity")
        if not isinstance(identity, dict):
            raise TypeError(f"terminal receipt lacks run identity: {cell}")
        if (
            terminal.get("status") != "completed"
            or terminal.get("completed_epochs") != 4
            or terminal.get("global_updates") != core.FIT_UPDATES
            or identity.get("world_size") != 2
            or checkpoint_sha != terminal.get("model_sha256")
            or checkpoint_sha != producer.get("checkpoint_sha256")
            or producer.get("config") != config
            or producer.get("teacher") is not None
            or "reference" in producer
            or producer.get("provenance", {}).get("identity") != identity
            or producer.get("provenance", {}).get("profile_receipt", {}).get("sha256")
            != profile_sha
            or identity.get("source_sha256") != expected_source["sha256"]
            or identity.get("source_files") != expected_source["files"]
        ):
            raise ValueError(f"incomplete or foreign fixed-final endpoint: {cell}")
        runtime = identity.get("runtime")
        if not isinstance(runtime, dict):
            raise TypeError(f"terminal receipt lacks runtime: {cell}")
        authority_uuids = [
            str(uuid).removeprefix("GPU-")
            for uuid in authority["configs"][cell]["gpu_uuids"]
        ]
        normalized_runtime = runtime_without_device_uuids(runtime, authority_uuids)
        seed_runtimes[seed].add(canonical_sha256(normalized_runtime))
        common_hashes.add(canonical_sha256(panel.comparable_identity(producer)))
        identity_hashes[cell] = {
            "checkpoint_sha256": checkpoint_sha,
            "score_sha256": sha256_file(fit / "score.json"),
            "approved_profile_sha256": profile_sha,
            "normalized_runtime_sha256": canonical_sha256(normalized_runtime),
        }
        rows[cell] = {"score": score, "producer": producer}
    if (
        len(template_hashes) != 1
        or len(common_hashes) != 1
        or any(len(values) != 1 for values in seed_runtimes.values())
    ):
        raise ValueError(
            "panel changes recipe/data/optimizer/runtime beyond declared GPU UUIDs"
        )
    contrasts, deltas = [], []
    for seed in (203301, 203302):
        candidate = rows[f"rms_s{seed}"]["score"]
        control_score = rows[f"plain_s{seed}"]["score"]
        result = panel.contrast(candidate, control_score)
        delta = float(candidate["score"]["wp"] - control_score["score"]["wp"])
        deltas.append(delta)
        contrasts.append(
            {
                "seed": seed,
                "candidate": "rms",
                "control": "plain",
                "candidate_wp": candidate["score"]["wp"],
                "control_wp": control_score["score"]["wp"],
                "rms_minus_plain": delta,
                **result,
            }
        )
    mean_delta = sum(deltas) / len(deltas)
    return {
        "schema": "wnn.b300-qknorm-fourpairs-comparison.r1",
        "status": "complete_exposed_fixed4E_screen",
        "split_sha256": core.SPLIT_SHA256,
        "source_commit": core.COMMIT,
        "source_sha256": core.SOURCE_SHA256,
        "scores": {cell: rows[cell]["score"]["score"] for cell in core.CELLS},
        "contrasts": contrasts,
        "receipt_sha256": identity_hashes,
        "mean_rms_minus_plain": mean_delta,
        "followup_budget_trigger_only": min(deltas) > 0 and mean_delta >= 0.0005,
        "automatic_next_fit": False,
        "comparison_policy": {
            "canonical_scorer": "pinned PR75 score_sequence.py",
            "panel_helpers": "pinned PR75 compare_panel.py grade/comparable_identity/contrast",
            "four_pair_amendment": "Only rank device UUIDs may differ between same-seed arms; all other runtime fields and all source/software/precision/config/data ancestry are checked exactly.",
            "runtime_uuid_map": {
                cell: authority["configs"][cell]["gpu_uuids"] for cell in core.CELLS
            },
        },
        "uncertainty": "Two fitting seeds on one exposed split; component bootstrap conditions on fixed fitted predictors. No significance, public-gain or CPU-serving claim.",
    }


def main() -> int:
    """Write one bounded pair report after all four canonical scores are complete."""
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--split", type=Path, required=True)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--authority-sha256", required=True)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    authority = core.read_authority(args.authority, args.authority_sha256, root)
    output = root / "comparison-fourpair.json"
    if output.exists() or output.is_symlink():
        raise FileExistsError("comparison receipt exists; no automatic rewrite")
    result = compare(
        root,
        args.source.resolve(strict=True),
        args.data_root.resolve(strict=True),
        args.split.resolve(strict=True),
        authority,
    )
    with output.open("x", encoding="utf-8") as stream:
        stream.write(
            json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
