"""ROOT-authorized readout-only PR75 QK receiver; it never starts or resumes fits."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_driver_support_r1 as support
import b300_owned_runner_r2 as runner
import b300_qknorm_core_r1 as core
import b300_qknorm_driver_r1 as fit_driver

core.bind_legacy_contract()
support.run_owned = runner.run_owned


def _detach(args: argparse.Namespace) -> dict[str, Any]:
    """Start one detached readout controller and record its birth-bound identity."""
    root = args.root.resolve(strict=True)
    control = root / "control" / fit_driver.CONTROL_NAME / "detached"
    control.mkdir(parents=True, exist_ok=True)
    owner_path, log_path = control / "readout-owner.json", control / "readout.log"
    if any(path.exists() or path.is_symlink() for path in (owner_path, log_path)):
        raise FileExistsError(
            "readout already has a detached owner/log; restart is disabled"
        )
    child_args = [value for value in sys.argv[1:] if value != "--detach"]
    command = [
        str(args.python or sys.executable),
        "-u",
        str(Path(__file__).absolute()),
        *child_args,
    ]
    with log_path.open("xb") as stream:
        process = subprocess.Popen(
            command,
            cwd=root,
            stdin=subprocess.DEVNULL,
            stdout=stream,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
    child = None
    for _ in range(100):
        child = legacy.proc_entry(process.pid)
        if child is not None:
            break
        time.sleep(0.02)
    if child is None:
        raise RuntimeError("readout controller exited before birth could be recorded")
    receipt = {
        "schema": "wnn.b300-qknorm-readout-detached-owner.r1",
        "controller": {"pid": child.pid, "birth_ticks": child.start_ticks},
        "command": command,
        "log_path": str(log_path),
        "created_epoch": time.time(),
    }
    legacy.atomic_json(owner_path, receipt)
    return receipt


def main(argv: list[str] | None = None) -> int:
    """Export/score only after the separately admitted four fits finish successfully."""
    args = fit_driver._parser().parse_args(argv)
    if args.phase != "readout":
        raise ValueError("readout receiver requires --phase readout")
    if args.detach:
        print(json.dumps(_detach(args), sort_keys=True))
        return 0
    if os.name != "posix":
        raise RuntimeError("B300 readout receiver must run on ROOT-owned Linux")
    import fcntl

    (
        authority,
        configs,
        values,
        config_shas,
        _source_files,
        root,
        source,
        data_root,
        split,
        python,
        control,
        _authority_path,
    ) = fit_driver._prepare(args)
    lock_stream = (control / "phase.lock").open("a+b")
    try:
        fcntl.flock(lock_stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error:
        lock_stream.close()
        raise RuntimeError(
            "another QK receiver phase still owns the run root"
        ) from error
    phase = control / "readout"
    phase.mkdir(exist_ok=True)
    owner_path, state_path = phase / "owner.json", phase / "status.json"
    if any(path.exists() or path.is_symlink() for path in (owner_path, state_path)):
        fcntl.flock(lock_stream.fileno(), fcntl.LOCK_UN)
        lock_stream.close()
        raise FileExistsError("readout phase already ran; retries are disabled")
    owner = support._identity(root)
    started = time.time()
    legacy.atomic_json(
        owner_path,
        {
            "schema": "wnn.b300-qknorm-phase-owner.r1",
            "phase": "readout",
            "owner": owner,
            "source_sha256": core.SOURCE_SHA256,
            "source_commit": core.COMMIT,
            "authority_sha256": args.authority_sha256,
            "started_epoch": started,
        },
    )
    legacy.atomic_json(
        state_path,
        {
            "schema": "wnn.b300-qknorm-phase-status.r1",
            "phase": "readout",
            "status": "running",
            "owner": owner,
            "cells": {},
            "started_epoch": started,
        },
    )
    state_lock = __import__("threading").Lock()
    guard = runner.ResourceGuard(root, control, support._caps(authority))
    try:
        stat = os.statvfs(root)
        if legacy.directory_bytes(root) > authority["budget"]["output_bytes"]:
            raise OSError("native output exceeds the authority cap")
        if stat.f_bavail * stat.f_frsize < authority["budget"]["minimum_free_bytes"]:
            raise OSError("native free space is below the authority reserve")
        from b300_qknorm_readout_r1 import run_readout

        result = run_readout(
            authority=authority,
            configs=configs,
            values=values,
            config_shas=config_shas,
            root=root,
            source=source,
            python=python,
            data_root=data_root,
            split=split,
            control=control,
            guard=guard,
            owner=owner,
            state_path=state_path,
            state_lock=state_lock,
        )
    except Exception as error:
        finished = time.time()
        state = legacy.read_json(state_path, 4_000_000)
        state.update(
            status="failed",
            error=f"{type(error).__name__}: {error}",
            completed_epoch=finished,
        )
        legacy.atomic_json(state_path, state, replace=True)
        phase_owner = legacy.read_json(owner_path, 64_000)
        phase_owner.update(
            status="failed",
            error=f"{type(error).__name__}: {error}",
            completed_epoch=finished,
        )
        legacy.atomic_json(owner_path, phase_owner, replace=True)
        raise
    state = legacy.read_json(state_path, 4_000_000)
    state.update(status=result["status"], summary=result, completed_epoch=time.time())
    legacy.atomic_json(state_path, state, replace=True)
    phase_owner = legacy.read_json(owner_path, 64_000)
    phase_owner.update(
        status=result["status"], completed_epoch=state["completed_epoch"]
    )
    legacy.atomic_json(owner_path, phase_owner, replace=True)
    print(json.dumps({"phase": "readout", "status": result["status"]}, sort_keys=True))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
