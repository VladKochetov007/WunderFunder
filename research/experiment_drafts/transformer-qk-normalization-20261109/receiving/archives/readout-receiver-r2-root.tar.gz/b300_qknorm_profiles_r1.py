"""Run the four pinned PR75 production and zero-warmup engineering profiles."""

from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_driver_support_r1 as support
import b300_owned_runner_r2 as runner
import b300_qknorm_core_r1 as core

support.run_owned = runner.run_owned
_base_environment = support._environment


def _environment(source: Path, root: Path, uuids: list[str]) -> dict[str, str]:
    """Use the reviewed runtime environment and explicitly enable 10-second heartbeat."""
    env = _base_environment(source, root, uuids)
    env["WNN_MONITOR_HEARTBEAT_SECONDS"] = "10"
    return env


support._environment = _environment
_run_stage = support._run_stage


def _acceptance(
    *,
    python: Path,
    source: Path,
    root: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
    mode: str,
    cell: str,
    deadline: float,
) -> None:
    """Invoke the exact PR75 acceptance entrypoint with the frozen data arguments."""
    packet = source / "research/experiment_drafts/transformer-qk-normalization-20261109"
    command = [
        str(python),
        str(packet / "acceptance.py"),
        "--mode",
        mode,
        "--root",
        str(root),
        "--commit",
        core.COMMIT,
        "--split",
        str(split),
        "--data-root",
        str(data_root),
    ]
    if mode == "profiles":
        command.extend(("--cell", cell))
    result = _run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell=cell or "preflight",
        stage=f"acceptance-{mode}",
        output=root,
        command=command,
        gpu_uuids=[],
        deadline=deadline,
        timeout=900,
        state_path=state_path,
        state_lock=state_lock,
    )
    if result.get("status") != "completed":
        raise runner.OwnedRunError(f"canonical PR75 acceptance {mode} failed")


def _data_check(
    *,
    python: Path,
    source: Path,
    root: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
    deadline: float,
) -> None:
    """Create the canonical data receipt once or verify the already staged bytes."""
    output = root / "data-check.json"
    if not output.exists() and not output.is_symlink():
        packet = (
            source / "research/experiment_drafts/transformer-qk-normalization-20261109"
        )
        command = [
            str(python),
            str(packet / "receiver_data.py"),
            "--data-root",
            str(data_root),
            "--split-manifest",
            str(split),
            "--output",
            str(output),
        ]
        result = _run_stage(
            python=python,
            source=source,
            root=root,
            control=control,
            guard=guard,
            owner=owner,
            cell="preflight",
            stage="data-check",
            output=root,
            command=command,
            gpu_uuids=[],
            deadline=deadline,
            timeout=1_800,
            state_path=state_path,
            state_lock=state_lock,
        )
        if result.get("status") != "completed":
            raise runner.OwnedRunError("canonical PR75 data check failed")
    core.verify_data_check(output, data_root, split)


def _profile_cell(
    *,
    cell: str,
    item: dict[str, Any],
    config: dict[str, Any],
    config_sha: str,
    source_files: dict[str, str],
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    deadline: float,
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Run both fixed 50-update profiles on the assigned physical pair."""
    run_dir = root / "runs" / cell
    production_output = run_dir / "profile"
    peak_output = run_dir / "profile-peak"
    peak_config_path = run_dir / "profile-configs" / "peak.json"
    if any(
        path.exists() or path.is_symlink()
        for path in (production_output, peak_output, peak_config_path)
    ):
        raise FileExistsError(
            f"profile artifacts already exist for {cell}; retry is disabled"
        )
    uuids = [str(value).removeprefix("GPU-") for value in item["gpu_uuids"]]
    train_script = source / "scripts" / "train_sequence.py"
    base = [
        str(python),
        "-m",
        "torch.distributed.run",
        "--standalone",
        "--nnodes=1",
        "--nproc-per-node=2",
        str(train_script),
    ]
    common = [
        "--data-root",
        str(data_root),
        "--split-manifest",
        str(split),
        "--profile-updates",
        "50",
    ]
    production_result = _run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell=cell,
        stage="profile-production",
        output=production_output,
        command=[
            *base,
            "--config",
            str(item["path"]),
            *common,
            "--output",
            str(production_output),
        ],
        gpu_uuids=uuids,
        deadline=deadline,
        timeout=1_800,
        state_path=state_path,
        state_lock=state_lock,
    )
    if production_result.get("status") != "completed":
        raise runner.OwnedRunError(f"production profile process failed for {cell}")
    production = legacy.validate_profile_receipt(
        production_output / "profile_receipt.json",
        config=config,
        config_sha=config_sha,
        source_sha=core.SOURCE_SHA256,
        source_files=source_files,
        expected_split=core.SPLIT_SHA256,
        expected_uuids=uuids,
    )
    peak_config_path.parent.mkdir(parents=True, exist_ok=True)
    packet = source / "research/experiment_drafts/transformer-qk-normalization-20261109"
    maker = [
        str(python),
        str(packet / "profile_config.py"),
        "--config",
        str(item["path"]),
        "--output",
        str(peak_config_path),
    ]
    made = _run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell=cell,
        stage="make-peak-config",
        output=peak_config_path.parent,
        command=maker,
        gpu_uuids=[],
        deadline=deadline,
        timeout=300,
        state_path=state_path,
        state_lock=state_lock,
    )
    if made.get("status") != "completed":
        raise runner.OwnedRunError(f"peak config generation failed for {cell}")
    peak_config = support._load_native_config(source, peak_config_path)
    expected_peak = dict(config, warmup_fraction=0.0)
    if peak_config != expected_peak:
        raise ValueError(f"peak config changes more than warmup_fraction for {cell}")
    peak_sha = legacy.canonical_sha256(peak_config)
    peak_output_result = _run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell=cell,
        stage="profile-zero-warmup-peak",
        output=peak_output,
        command=[
            *base,
            "--config",
            str(peak_config_path),
            *common,
            "--output",
            str(peak_output),
        ],
        gpu_uuids=uuids,
        deadline=deadline,
        timeout=1_800,
        state_path=state_path,
        state_lock=state_lock,
    )
    if peak_output_result.get("status") != "completed":
        raise runner.OwnedRunError(f"zero-warmup profile process failed for {cell}")
    peak = legacy.validate_profile_receipt(
        peak_output / "profile_receipt.json",
        config=peak_config,
        config_sha=peak_sha,
        source_sha=core.SOURCE_SHA256,
        source_files=source_files,
        expected_split=core.SPLIT_SHA256,
        expected_uuids=uuids,
    )
    if production["identity"]["runtime"] != peak["identity"]["runtime"]:
        raise ValueError(f"production/peak runtime differs for {cell}")
    result = {
        "schema": "wnn.b300-qknorm-profile-cell.r1",
        "cell": cell,
        "status": "profiles_complete",
        "updates_each": 50,
        "raw_config_sha256": item["raw_sha256"],
        "config_sha256": config_sha,
        "peak_config_sha256": peak_sha,
        "pair": item["pair"],
        "gpu_uuids": uuids,
        "production_receipt_sha256": legacy.sha256_file(
            production_output / "profile_receipt.json"
        ),
        "peak_receipt_sha256": legacy.sha256_file(peak_output / "profile_receipt.json"),
        "production_runtime": production["identity"]["runtime"],
        "automatic_retry": False,
    }
    legacy.atomic_json(control / "profiles" / f"{cell}.json", result)
    return result


def run_profiles(
    *,
    authority: dict[str, Any],
    configs: dict[str, dict[str, Any]],
    values: dict[str, dict[str, Any]],
    config_shas: dict[str, str],
    source_files: dict[str, str],
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Profile all four cells in parallel; this phase cannot fit or approve."""
    clock_path = Path(authority["clock_path"])
    first, fit_deadline, wave_deadline = core.validate_clock(clock_path, authority)
    if time.time() >= fit_deadline:
        raise TimeoutError("original four-hour fit window has closed")
    _data_check(
        python=python,
        source=source,
        root=root,
        data_root=data_root,
        split=split,
        control=control,
        guard=guard,
        owner=owner,
        state_path=state_path,
        state_lock=state_lock,
        deadline=fit_deadline,
    )
    _acceptance(
        python=python,
        source=source,
        root=root,
        data_root=data_root,
        split=split,
        control=control,
        guard=guard,
        owner=owner,
        state_path=state_path,
        state_lock=state_lock,
        mode="verify",
        cell="",
        deadline=fit_deadline,
    )
    outcomes: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(
        max_workers=4, thread_name_prefix="qk-profile-pair"
    ) as pool:
        futures = {
            pool.submit(
                _profile_cell,
                cell=cell,
                item=configs[cell],
                config=values[cell],
                config_sha=config_shas[cell],
                source_files=source_files,
                root=root,
                source=source,
                python=python,
                data_root=data_root,
                split=split,
                control=control,
                guard=guard,
                owner=owner,
                deadline=fit_deadline,
                state_path=state_path,
                state_lock=state_lock,
            ): cell
            for cell in core.CELLS
        }
        for future in as_completed(futures):
            cell = futures[future]
            try:
                outcomes[cell] = future.result()
            except Exception as error:  # noqa: BLE001 - persist every worker outcome.
                outcomes[cell] = {
                    "schema": "wnn.b300-qknorm-profile-cell.r1",
                    "cell": cell,
                    "status": "profile_failed",
                    "error": f"{type(error).__name__}: {error}",
                    "automatic_retry": False,
                }
    complete = set(outcomes) == set(core.CELLS) and all(
        item.get("status") == "profiles_complete" for item in outcomes.values()
    )
    summary = {
        "schema": "wnn.b300-qknorm-profiles-summary.r1",
        "status": "profiles_complete" if complete else "profiles_partial_or_failed",
        "source_sha256": core.SOURCE_SHA256,
        "source_commit": core.COMMIT,
        "authority_sha256": legacy.sha256_file(control / "authority.json"),
        "split_sha256": core.SPLIT_SHA256,
        "first_profile_epoch": first,
        "fit_deadline_epoch": fit_deadline,
        "wave_deadline_epoch": wave_deadline,
        "cells": outcomes,
        "scientific_fits_started": 0,
        "automatic_retry": False,
        "root_manual_fit_admission_required": True,
    }
    legacy.atomic_json(control / "profiles-complete.json", summary)
    return summary
