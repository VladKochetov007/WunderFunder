"""Export and score every fixed PR75 endpoint, then run the four-pair comparator."""

from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy
import b300_driver_fits_r1 as fit_checks
import b300_driver_support_r1 as support
import b300_owned_runner_r2 as runner
import b300_qknorm_core_r1 as core

core.bind_legacy_contract()
support.run_owned = runner.run_owned
_base_environment = support._environment


def _environment(source: Path, root: Path, uuids: list[str]) -> dict[str, str]:
    """Bound exports use one owned GPU; scoring/comparison use bounded one-thread CPU."""
    env = _base_environment(source, root, uuids)
    env["WNN_MONITOR_HEARTBEAT_SECONDS"] = "10"
    if not uuids:
        for key in (
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
        ):
            env[key] = "1"
    return env


support._environment = _environment


def _run_acceptance(
    *,
    python: Path,
    source: Path,
    root: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
    deadline: float,
) -> None:
    """Recheck the pinned PR75 test/data admission before any prediction process."""
    packet = source / "research/experiment_drafts/transformer-qk-normalization-20261109"
    command = [
        str(python),
        str(packet / "acceptance.py"),
        "--mode",
        "verify",
        "--root",
        str(root),
        "--commit",
        core.COMMIT,
        "--split",
        str(split),
        "--data-root",
        str(data_root),
    ]
    result = support._run_stage(
        python=python,
        source=source,
        root=root,
        control=control,
        guard=guard,
        owner=owner,
        cell="readout",
        stage="acceptance-verify",
        output=root,
        command=command,
        gpu_uuids=[],
        deadline=deadline,
        timeout=900,
        state_path=state_path,
        state_lock=state_lock,
    )
    if result.get("status") != "completed":
        raise runner.OwnedRunError(
            "canonical PR75 acceptance check failed before readout"
        )


def _readout_cell(
    *,
    cell: str,
    item: dict[str, Any],
    config: dict[str, Any],
    config_sha: str,
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    deadline: float,
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Run one canonical evaluation-membership export and official sequence score."""
    fit_dir = root / "runs" / cell / "fit"
    evaluation_dir = root / "runs" / cell / "evaluation"
    score_path = fit_dir / "score.json"
    try:
        if (
            evaluation_dir.exists()
            or evaluation_dir.is_symlink()
            or score_path.exists()
            or score_path.is_symlink()
        ):
            raise FileExistsError(
                f"readout outputs already exist for {cell}; retry is disabled"
            )
        uuids = [str(uuid).removeprefix("GPU-") for uuid in item["gpu_uuids"]]
        checkpoint = fit_dir / "model.pt"
        terminal = legacy.read_json(fit_dir / "terminal_status.json", 2_000_000)
        if terminal.get("status") != "completed" or terminal.get(
            "model_sha256"
        ) != legacy.sha256_file(checkpoint):
            raise ValueError(
                f"fixed endpoint checkpoint receipt is incomplete for {cell}"
            )
        fit_checks._fit_metrics(
            root, cell, config, config_sha, core.SOURCE_SHA256, uuids
        )
        prediction = [
            str(python),
            str(source / "scripts" / "predict_sequence.py"),
            "--checkpoint",
            str(checkpoint),
            "--data-root",
            str(data_root),
            "--split-manifest",
            str(split),
            "--membership",
            "evaluation",
            "--output",
            str(evaluation_dir),
        ]
        export_owned = support._run_stage(
            python=python,
            source=source,
            root=root,
            control=control,
            guard=guard,
            owner=owner,
            cell=cell,
            stage="final-evaluation-export",
            output=evaluation_dir,
            command=prediction,
            gpu_uuids=[uuids[0]],
            deadline=deadline,
            timeout=min(1_200, max(1, int(deadline - time.time()))),
            state_path=state_path,
            state_lock=state_lock,
        )
        if export_owned.get("status") != "completed":
            raise runner.OwnedRunError(f"canonical prediction export failed for {cell}")
        score = [
            str(python),
            str(source / "scripts" / "score_sequence.py"),
            "--data-root",
            str(data_root),
            "--split-manifest",
            str(split),
            "--predictions",
            str(evaluation_dir),
            "--output",
            str(score_path),
        ]
        score_owned = support._run_stage(
            python=python,
            source=source,
            root=root,
            control=control,
            guard=guard,
            owner=owner,
            cell=cell,
            stage="official-valid-score",
            output=fit_dir,
            command=score,
            gpu_uuids=[],
            deadline=deadline,
            timeout=min(600, max(1, int(deadline - time.time()))),
            state_path=state_path,
            state_lock=state_lock,
        )
        if score_owned.get("status") != "completed":
            raise runner.OwnedRunError(f"canonical scorer failed for {cell}")
        from b300_qknorm_compare_r1 import _panel_module

        panel = _panel_module(source)
        value = panel.grade(score_path)
        prediction_manifest = legacy.read_json(
            evaluation_dir / "manifest.json", 32_000_000
        )
        producer = value.get("producer")
        if (
            prediction_manifest.get("complete") is not True
            or prediction_manifest.get("membership") != "evaluation"
            or prediction_manifest.get("split_sha256") != core.SPLIT_SHA256
            or prediction_manifest.get("sequences") != core.VALID_MEMBERS
            or not isinstance(producer, dict)
            or producer.get("checkpoint_sha256") != terminal.get("model_sha256")
            or producer.get("split_sha256") != core.SPLIT_SHA256
        ):
            raise ValueError(
                f"evaluation manifest/score differs from fixed endpoint for {cell}"
            )
        return {
            "schema": "wnn.b300-qknorm-readout-cell.r1",
            "cell": cell,
            "status": "readout_complete",
            "checkpoint_sha256": terminal["model_sha256"],
            "prediction_manifest_sha256": legacy.sha256_file(
                evaluation_dir / "manifest.json"
            ),
            "score_sha256": legacy.sha256_file(score_path),
            "score": value["score"],
            "owned_export": export_owned,
            "owned_score": score_owned,
            "completed_epoch": time.time(),
        }
    except Exception as error:  # noqa: BLE001 - retain each cell's outcome; no retry.
        return {
            "schema": "wnn.b300-qknorm-readout-cell.r1",
            "cell": cell,
            "status": "readout_failed_or_partial",
            "error": f"{type(error).__name__}: {error}",
            "automatic_retry": False,
            "observed_epoch": time.time(),
        }


def run_readout(
    *,
    authority: dict[str, Any],
    configs: dict[str, dict[str, Any]],
    values: dict[str, dict[str, Any]],
    config_shas: dict[str, str],
    root: Path,
    source: Path,
    python: Path,
    data_root: Path,
    split: Path,
    control: Path,
    guard: Any,
    owner: dict[str, Any],
    state_path: Path,
    state_lock: threading.Lock,
) -> dict[str, Any]:
    """Require all four fit completions, export once per cell, then compare paired metrics."""
    first, fit_deadline, wave_deadline = core.validate_clock(
        Path(authority["clock_path"]), authority
    )
    if time.time() >= wave_deadline:
        raise TimeoutError("original five-hour collection deadline has closed")
    fit_control = control / "fit"
    fit_owner = legacy.read_json(fit_control / "owner.json", 64_000)
    summary = legacy.read_json(control / "fits-complete.json", 4_000_000)
    if (
        fit_owner.get("status") != "complete"
        or summary.get("status") != "complete"
        or summary.get("source_sha256") != core.SOURCE_SHA256
        or set(summary.get("fits", {})) != set(core.CELLS)
        or any(
            summary["fits"][cell].get("status") != "fit_complete" for cell in core.CELLS
        )
    ):
        raise ValueError("readout requires all four completed 4E fit receipts")
    core.verify_data_check(root / "data-check.json", data_root, split)
    _run_acceptance(
        python=python,
        source=source,
        root=root,
        data_root=data_root,
        split=split,
        control=control,
        guard=guard,
        owner=owner,
        state_path=state_path,
        state_lock=state_lock,
        deadline=wave_deadline,
    )
    results: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(
        max_workers=4, thread_name_prefix="qk-readout-pair"
    ) as pool:
        futures = {
            pool.submit(
                _readout_cell,
                cell=cell,
                item=configs[cell],
                config=values[cell],
                config_sha=config_shas[cell],
                root=root,
                source=source,
                python=python,
                data_root=data_root,
                split=split,
                control=control,
                guard=guard,
                owner=owner,
                deadline=wave_deadline,
                state_path=state_path,
                state_lock=state_lock,
            ): cell
            for cell in core.CELLS
        }
        for future in as_completed(futures):
            cell = futures[future]
            try:
                results[cell] = future.result()
            except Exception as error:  # noqa: BLE001 - persist independent export failures.
                results[cell] = {
                    "schema": "wnn.b300-qknorm-readout-cell.r1",
                    "cell": cell,
                    "status": "readout_controller_failed",
                    "error": f"{type(error).__name__}: {error}",
                    "automatic_retry": False,
                }
            legacy.atomic_json(
                control / "readout-stream-status.json",
                {
                    "schema": "wnn.b300-qknorm-readout-stream-status.r1",
                    "cells": results,
                    "updated_epoch": time.time(),
                },
                replace=True,
            )
    complete = set(results) == set(core.CELLS) and all(
        value.get("status") == "readout_complete" for value in results.values()
    )
    comparison = None
    if complete:
        comparison_path = root / "comparison-fourpair.json"
        if comparison_path.exists() or comparison_path.is_symlink():
            raise FileExistsError("four-pair comparison already exists; no rewrite")
        command = [
            str(python),
            str(Path(__file__).with_name("b300_qknorm_compare_r1.py")),
            "--root",
            str(root),
            "--source",
            str(source),
            "--data-root",
            str(data_root),
            "--split",
            str(split),
            "--authority",
            str(control / "authority.json"),
            "--authority-sha256",
            legacy.sha256_file(control / "authority.json"),
        ]
        compare_owned = support._run_stage(
            python=python,
            source=source,
            root=root,
            control=control,
            guard=guard,
            owner=owner,
            cell="panel",
            stage="four-pair-component-comparison",
            output=root,
            command=command,
            gpu_uuids=[],
            deadline=wave_deadline,
            timeout=min(600, max(1, int(wave_deadline - time.time()))),
            state_path=state_path,
            state_lock=state_lock,
        )
        if compare_owned.get("status") != "completed":
            raise runner.OwnedRunError("four-pair comparison process failed")
        comparison = {
            "path": str(comparison_path),
            "sha256": legacy.sha256_file(comparison_path),
            "owned_process": compare_owned,
        }
    result = {
        "schema": "wnn.b300-qknorm-readout-summary.r1",
        "status": "complete"
        if complete and comparison is not None
        else "partial_or_failed",
        "source_sha256": core.SOURCE_SHA256,
        "authority_sha256": legacy.sha256_file(control / "authority.json"),
        "split_sha256": core.SPLIT_SHA256,
        "first_profile_epoch": first,
        "fit_deadline_epoch": fit_deadline,
        "wave_deadline_epoch": wave_deadline,
        "readouts": results,
        "comparison": comparison,
        "automatic_retry": False,
    }
    legacy.atomic_json(control / "readout-complete.json", result)
    return result


if __name__ == "__main__":
    raise SystemExit(
        "Invoke b300_qknorm_readout_driver_r1.py with its ROOT-signed authority CLI"
    )
