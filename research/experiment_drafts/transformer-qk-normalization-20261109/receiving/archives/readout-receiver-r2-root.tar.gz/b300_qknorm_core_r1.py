"""PR75 QK-normalization receiver gates built around the pinned source capsule."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import b300_driver_core_r1 as legacy

COMMIT = "8626000a4b965763a70011a0291a891aa6535d7e"
SOURCE_SHA256 = "931a91046efb0f84e68184862e80076bb2751522bc6264fffa06e3cab36931fd"
MANIFEST_SHA256 = "cb154b75d67fa63740be93264386644bcaab8f7f13952cb7e73935b49b612052"
ARCHIVE_SHA256 = "08f8e31d18a523ba7c543fe71fa3b31799cfe1af566672d6b903e30beac639f5"
SPLIT_SHA256 = "0c4de3a253d23b3a5d5ca73b7aeb7fcae2b974673e4f9ec51e94e593c59d114c"
CELLS = ("plain_s203301", "rms_s203301", "plain_s203302", "rms_s203302")
PAIRS = {
    cell: list(pair) for cell, pair in zip(CELLS, ((0, 1), (2, 3), (4, 5), (6, 7)))
}
SEEDS = {
    "plain_s203301": 203301,
    "rms_s203301": 203301,
    "plain_s203302": 203302,
    "rms_s203302": 203302,
}
FIT_MEMBERS, VALID_MEMBERS, SCORED_ROWS = 10_325, 1_873, 3_528_273
UPDATES_PER_EPOCH, FIT_UPDATES = 820, 3_280
AUTHORITY_SCHEMA = "wnn.b300-qknorm-fourpairs-authority.v1"
ADMISSION_SCHEMA = "wnn.b300-qknorm-fourpairs-fit-admission.v1"


def bind_legacy_contract() -> None:
    """Set only shared receipt-check constants before importing legacy check helpers."""
    legacy.COMMIT = COMMIT
    legacy.SOURCE_SHA256 = SOURCE_SHA256
    legacy.MANIFEST_SHA256 = MANIFEST_SHA256
    legacy.SPLIT_SHA256 = SPLIT_SHA256
    legacy.CELLS = CELLS
    legacy.TRAIN_MEMBERS = FIT_MEMBERS
    legacy.VALID_MEMBERS = VALID_MEMBERS
    legacy.SCORED_ROWS = SCORED_ROWS
    legacy.UPDATES_PER_EPOCH = UPDATES_PER_EPOCH
    legacy.FIT_UPDATES = FIT_UPDATES


def read_authority(path: Path, expected_sha: str, root: Path) -> dict[str, Any]:
    """Require the exact ROOT-signed QK authority and four fixed pair allocations."""
    if legacy.sha256_file(path) != expected_sha:
        raise ValueError("authority file bytes differ from --authority-sha256")
    value = legacy.read_json(path, 256_000)
    source = value.get("source")
    budget = value.get("budget")
    configs = value.get("configs")
    if (
        value.get("schema") != AUTHORITY_SCHEMA
        or value.get("approved") is not True
        or Path(str(value.get("native_root"))).as_posix() != root.as_posix()
        or not isinstance(source, dict)
        or source.get("commit") != COMMIT
        or source.get("source_sha256") != SOURCE_SHA256
        or source.get("manifest_sha256") != MANIFEST_SHA256
        or source.get("archive_sha256") != ARCHIVE_SHA256
        or value.get("split_sha256") != SPLIT_SHA256
        or value.get("world_size") != 2
        or value.get("epochs") != 4
        or value.get("updates_per_epoch") != UPDATES_PER_EPOCH
        or value.get("updates_per_fit") != FIT_UPDATES
        or value.get("fit_members") != FIT_MEMBERS
        or value.get("evaluation_members") != VALID_MEMBERS
        or value.get("scored_rows") != SCORED_ROWS
        or value.get("precision") != "bf16_bf16x9"
        or value.get("new_fits") != 4
        or value.get("fit_pair_streams")
        != {"0,1": [CELLS[0]], "2,3": [CELLS[1]], "4,5": [CELLS[2]], "6,7": [CELLS[3]]}
        or value.get("profile_waves") != [list(CELLS)]
        or value.get("profiles", {}).get("count") != 8
        or value.get("profiles", {}).get("updates_each") != 50
        or value.get("profiles", {}).get("require_both_rank_full_state_reload")
        is not True
        or value.get("profiles", {}).get("scientific_fits_admitted") != 0
        or not isinstance(configs, dict)
        or set(configs) != set(CELLS)
    ):
        raise ValueError("authority differs from frozen PR75 four-pair contract")
    if not isinstance(budget, dict) or any(
        budget.get(name) != expected
        for name, expected in {
            "wall_seconds": 18_000,
            "fit_seconds": 14_400,
            "collection_seconds": 3_600,
            "profile_stage_timeout_seconds": 1_800,
            "output_bytes": 100_000_000_000,
            "minimum_free_bytes": 100_000_000_000,
            "owned_rss_bytes": 274_877_906_944,
            "threads_per_rank": 8,
        }.items()
    ):
        raise ValueError(
            "authority resource/deadline limits differ from ROOT's contract"
        )
    uuids: list[str] = []
    for cell in CELLS:
        item = configs[cell]
        seed = SEEDS[cell]
        norm = "rms" if cell.startswith("rms_") else "none"
        if (
            not isinstance(item, dict)
            or item.get("seed") != seed
            or item.get("qk_norm") != norm
            or item.get("pair") != PAIRS[cell]
            or not isinstance(item.get("gpu_uuids"), list)
            or len(item["gpu_uuids"]) != 2
            or any(not isinstance(uuid, str) or not uuid for uuid in item["gpu_uuids"])
            or not isinstance(item.get("path"), str)
            or not isinstance(item.get("raw_sha256"), str)
            or not isinstance(item.get("config_sha256"), str)
        ):
            raise ValueError(f"cell authority is malformed: {cell}")
        uuids.extend(item["gpu_uuids"])
    if len(set(uuids)) != 8:
        raise ValueError("authority must assign eight distinct physical B300 UUIDs")
    for key in ("data_root", "split", "python", "clock_path", "fit_admission_path"):
        if not isinstance(value.get(key), str) or not Path(value[key]).is_absolute():
            raise ValueError(f"authority has no absolute {key}")
    if (
        Path(value["clock_path"]).as_posix()
        != (root / "receipts" / "clock-r2.json").as_posix()
    ):
        raise ValueError(
            "authority clock path differs from the original first-profile clock"
        )
    if (
        Path(value["fit_admission_path"]).as_posix()
        != (root / "control" / "ROOT-fit-admission-r1.json").as_posix()
    ):
        raise ValueError("authority admission path differs from ROOT's fixed path")
    amendment = value.get("user_budget_amendment")
    if (
        not isinstance(amendment, dict)
        or amendment.get("total_seconds") != 18_000
        or amendment.get("fit_seconds") != 14_400
        or amendment.get("first_gpu_epoch_unchanged") is None
        or amendment.get("fit_deadline_epoch") is None
        or amendment.get("wave_deadline_epoch") is None
    ):
        raise ValueError(
            "authority omits the explicit same-first-event 5h budget amendment"
        )
    return value


def verify_configs(
    source: Path, configs: dict[str, dict[str, Any]]
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Hash raw bytes, load via the pinned parser, and freeze the four-cell recipe deltas."""
    from b300_driver_support_r1 import _load_native_config

    loaded: dict[str, dict[str, Any]] = {}
    shas: dict[str, str] = {}
    templates = set()
    for cell in CELLS:
        item = configs[cell]
        path = Path(item["path"])
        if path.is_symlink() or not path.resolve(strict=True).is_relative_to(source):
            raise ValueError(f"config is linked or outside the pinned source: {cell}")
        if legacy.sha256_file(path) != item["raw_sha256"]:
            raise ValueError(f"raw config hash differs for {cell}")
        raw = legacy.read_json(path, 64_000)
        model_raw = raw.get("model")
        norm = "rms" if cell.startswith("rms_") else "none"
        if (
            raw.get("seed") != SEEDS[cell]
            or not isinstance(model_raw, dict)
            or model_raw.get("qk_norm", "none") != norm
        ):
            raise ValueError(f"raw qk_norm/seed differs from assigned cell {cell}")
        config = _load_native_config(source, path)
        model = config.get("model")
        expected = {
            "epochs": 4,
            "batch_size": 128,
            "accumulate_chunks": 4,
            "chunk_rows": 256,
            "gradient_horizon_rows": 256,
            "optimizer": "muon",
            "lr": 0.0003,
            "weight_decay": 0.01,
            "warmup_fraction": 0.05,
            "schedule": "warmup_cosine_v2",
            "min_lr_ratio": 0.1,
            "precision_mode": "bf16_bf16x9",
            "required_world_size": 2,
            "required_device": "B300",
            "checkpoint_retention": "all_epochs",
            "checkpoint_endpoint_policy": "configured_final_epoch",
            "objective_mode": "standalone_labels_wmse_v2",
            "training_mask": "all_after_warmup",
            "normalization_scope": "all_fit",
            "optimizer_update_diagnostics_every": 50,
        }
        if any(config.get(key) != value for key, value in expected.items()):
            raise ValueError(
                f"optimizer/objective/schedule contract differs for {cell}"
            )
        if (
            not isinstance(model, dict)
            or any(
                model.get(key) != value
                for key, value in {
                    "architecture": "transformer",
                    "hidden": 768,
                    "layers": 24,
                    "heads": 12,
                    "ff_multiplier": 4,
                    "context_rows": 1024,
                    "hint_dim": 0,
                    "attention_backend": "efficient",
                    "compile_blocks": True,
                }.items()
            )
            or model.get("qk_norm", "none") != norm
            or config.get("monitoring")
            != {
                "train_eval_sequences": 128,
                "eval_batch_size": 4,
                "train_eval_selection": "hash_rank_v1",
            }
        ):
            raise ValueError(
                f"model, online monitoring or evaluation contract differs for {cell}"
            )
        digest = legacy.canonical_sha256(config)
        if digest != item["config_sha256"]:
            raise ValueError(f"normalized config identity differs for {cell}")
        normalized = copy.deepcopy(config)
        normalized.pop("seed")
        normalized["model"].pop("qk_norm", None)
        templates.add(legacy.canonical_sha256(normalized))
        loaded[cell], shas[cell] = config, digest
    if len(templates) != 1:
        raise ValueError("frozen cells differ beyond seed and model.qk_norm")
    return loaded, shas


def verify_data_check(path: Path, data_root: Path, split: Path) -> dict[str, Any]:
    """Require the canonical QK source-data receipt and official partition counts."""
    value = legacy.read_json(path, 32_000)
    split_sha = legacy.sha256_file(split)
    if split_sha != SPLIT_SHA256 or value != {
        "schema": "wnn.qk-norm-data-check.v1",
        "status": "validated",
        "data_root": str(data_root.resolve()),
        "split_sha256": split_sha,
        "fit_train": FIT_MEMBERS,
        "fit_valid": 0,
        "evaluation_valid": VALID_MEMBERS,
        "component_disjoint": True,
        "evaluation_exposure": "development_exposed",
        "new_model_executions": 0,
    }:
        raise ValueError("data check differs from pinned QK train-only membership")
    return value


def validate_clock(
    path: Path, authority: dict[str, Any] | None = None
) -> tuple[float, float, float]:
    """Require R2's 4h-fit/1h-collection cap and preserve the original first GPU event."""
    value = legacy.read_json(path, 16_000)
    first, fit, wave = (
        value.get("first_profile_epoch"),
        value.get("fit_deadline_epoch"),
        value.get("wave_deadline_epoch"),
    )
    if not all(
        isinstance(item, (int, float)) and not isinstance(item, bool)
        for item in (first, fit, wave)
    ):
        raise ValueError("R2 clock fields are malformed")
    first, fit, wave = float(first), float(fit), float(wave)
    history = legacy.read_json(path.parent / "first-profile-r1.json", 16_000)
    if abs(float(history.get("first_profile_epoch", -1)) - first) > 1:
        raise ValueError("R2 clock does not preserve the original R1 first-GPU event")
    if abs(fit - first - 14_400) > 1 or abs(wave - first - 18_000) > 1:
        raise ValueError(
            "R2 clock must retain the original event with 4h fit + 1h collection"
        )
    if authority is not None:
        amendment = authority["user_budget_amendment"]
        if any(
            abs(actual - float(amendment[key])) > 1
            for actual, key in (
                (first, "first_gpu_epoch_unchanged"),
                (fit, "fit_deadline_epoch"),
                (wave, "wave_deadline_epoch"),
            )
        ):
            raise ValueError(
                "clock timestamps differ from ROOT's immutable R2 authority"
            )
    return first, fit, wave


def validate_admission(
    path: Path,
    expected_sha: str,
    authority_sha: str,
    root: Path,
    authority: dict[str, Any],
    configs: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Recheck ROOT's four-profile release and every referenced immutable receipt."""
    actual_sha = legacy.sha256_file(path)
    value = legacy.read_json(path, 256_000)
    entries = value.get("profiles")
    if (
        actual_sha != expected_sha
        or value.get("schema") != ADMISSION_SCHEMA
        or value.get("approved") is not True
        or value.get("max_fresh_fits") != 4
        or value.get("source_sha256") != SOURCE_SHA256
        or value.get("source_root") != str(root / "source-r1")
        or value.get("authority_sha256") != authority_sha
        or value.get("split_sha256") != SPLIT_SHA256
        or not isinstance(entries, dict)
        or set(entries) != set(CELLS)
    ):
        raise ValueError(
            "ROOT fit admission is absent, late or differs from QK source/authority"
        )
    for cell in CELLS:
        item = entries[cell]
        cfg = authority["configs"][cell]
        if not isinstance(item, dict) or any(
            item.get(key) != expected
            for key, expected in {
                "config_sha256": cfg["config_sha256"],
                "raw_config_sha256": cfg["raw_sha256"],
                "pair": PAIRS[cell],
                "gpu_uuids": cfg["gpu_uuids"],
            }.items()
        ):
            raise ValueError(f"fit admission changes config or pair for {cell}")
        expected_paths = {
            "production_receipt_path": root
            / "runs"
            / cell
            / "profile"
            / "profile_receipt.json",
            "peak_receipt_path": root
            / "runs"
            / cell
            / "profile-peak"
            / "profile_receipt.json",
            "approved_receipt_path": root / "runs" / cell / "approved_profile.json",
        }
        for key, receipt_path in expected_paths.items():
            hash_key = key.removesuffix("_path") + "_sha256"
            if (
                item.get(key) != str(receipt_path)
                or receipt_path.is_symlink()
                or not receipt_path.is_file()
                or legacy.sha256_file(receipt_path) != item.get(hash_key)
            ):
                raise ValueError(f"admission does not bind {key} bytes for {cell}")
    return value


def validate_approved_profile(
    root: Path,
    source: Path,
    cell: str,
    config: dict[str, Any],
    config_sha: str,
    source_sha: str,
    source_files: dict[str, str],
    uuids: list[str],
) -> dict[str, Any]:
    """Verify exact production/peak reload receipts and explicit human approval."""
    base = root / "runs" / cell
    production_path = base / "profile" / "profile_receipt.json"
    peak_path = base / "profile-peak" / "profile_receipt.json"
    approved_path = base / "approved_profile.json"
    expected_split = SPLIT_SHA256
    production = legacy.validate_profile_receipt(
        production_path,
        config=config,
        config_sha=config_sha,
        source_sha=source_sha,
        source_files=source_files,
        expected_split=expected_split,
        expected_uuids=uuids,
    )
    peak_config = dict(config, warmup_fraction=0.0)
    peak_sha = legacy.canonical_sha256(peak_config)
    peak = legacy.validate_profile_receipt(
        peak_path,
        config=peak_config,
        config_sha=peak_sha,
        source_sha=source_sha,
        source_files=source_files,
        expected_split=expected_split,
        expected_uuids=uuids,
    )
    if production["identity"]["runtime"] != peak["identity"]["runtime"]:
        raise ValueError(f"production and peak profile runtimes differ for {cell}")
    approved = legacy.read_json(approved_path, 256_000)
    mutable = {"approved", "reviewer", "reviewed_at", "approval_note"}
    if (
        approved.get("approved") is not True
        or not isinstance(approved.get("reviewer"), str)
        or not approved["reviewer"].strip()
        or not isinstance(approved.get("reviewed_at"), str)
        or not approved["reviewed_at"].strip()
        or any(
            approved.get(key) != value
            for key, value in production.items()
            if key not in mutable
        )
    ):
        raise ValueError(
            f"approved profile does not preserve production evidence for {cell}"
        )
    return {"production": production_path, "peak": peak_path, "approved": approved_path}
