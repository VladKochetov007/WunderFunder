# Receiving B300 commands

These commands are prepared and unexecuted. Use an isolated clean checkout and
the team's provisioned Linux B300 environment. See `PUBLICATION.json` for the
implementation commit; pin that full SHA as `WNN_EXPECTED_COMMIT`. Do not change
any live checkout or occupy GPUs belonging to another run.

From the isolated repository root, replace the path examples with the preserved
canonical data, original split file and a fresh physical-disk output directory:

```bash
export WNN_EXPECTED_COMMIT='<full implementation SHA from PUBLICATION.json>'
export WNN_DATA_ROOT='/absolute/path/to/canonical/data'
export WNN_SPLIT='/absolute/path/to/original/chronological-split.json'
export WNN_RUN_ROOT='/absolute/path/on/persistent-disk/input-stem-r1'
export CUDA_VISIBLE_DEVICES='0,1'
PACKET=research/experiment_drafts/transformer-causal-input-stem-20261109
bash "$PACKET/run.sh" data-check
bash "$PACKET/run.sh" check
```

The GPU IDs are an example, not a reservation. Keep the same pair and order for
all three arms of a seed. A second verified pair may process the other seed;
all six cells must share the canonical data, software and source identity.
The wrapper requires exactly two GPUs per invocation. It does not select free
devices, create an environment, download data or start an observer/queue.

For each cell, execute both engineering phases before any fit:

```bash
CELL=plain_s203201
bash "$PACKET/run.sh" profile "$CELL"
bash "$PACKET/run.sh" profile-peak "$CELL"
```

Review both receipts under `$WNN_RUN_ROOT/runs/$CELL`, including errors, peak
allocated/reserved memory, wall time and both-rank model/optimizer/scheduler/RNG
reload. Preserve them. Make a reviewed copy of the production receipt at
`runs/$CELL/approved_profile.json`, changing only `approved` to `true` and adding
nonempty `reviewer`, `reviewed_at` and optional `approval_note`. No script here
approves a profile. The fit additionally checks the exact live runtime against
the approved production receipt.

After that cell is admitted:

```bash
bash "$PACKET/run.sh" fit "$CELL"
bash "$PACKET/run.sh" evaluate "$CELL"
bash "$PACKET/run.sh" bundle "$CELL"
```

Process `plain_s203201`, `k1_s203201`, `k16_s203201` in that order on one pair;
then `plain_s203202`, `k1_s203202`, `k16_s203202` on its assigned pair. The two
seed streams may be concurrent; do not run two cells on the same pair at once.
Each cell needs its own two profiles and explicit approval. The fixed endpoint
is E4/3,280 updates. Preserve failed outputs; the wrapper never automatically
retries or resumes. `resume CELL` is an explicit continuation from that cell's
safe `fit/training_state.pt`, only after failure and ownership review.

After all six fixed endpoint grades exist:

```bash
bash "$PACKET/run.sh" compare
```

`comparison.json` contains all six scores, every paired contrast and checkpoint,
score and approved-profile hashes. It does not select epochs or launch a follow-up.
The optional secondary route sets `WNN_REFERENCE_ROOT` to the exact frozen PR49
TL3 cache root, runs `evaluate-blend CELL` for **all six** endpoints, then runs
`compare-blend`. It never fits or tunes the fixed 90/10 mixture coefficient.

Preserve the complete run root. The standard bundle includes final weights and
resume state; all-epoch weights and index snapshots need a separate companion
archive if they are transported. These Transformer weights are a research
teacher artifact, not a CPU submission ZIP.
