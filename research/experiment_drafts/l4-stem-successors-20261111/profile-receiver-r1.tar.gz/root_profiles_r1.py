"""Run only six exact-config engineering profiles on the authorized L4 host."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import runpy
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

R = Path('/data/lc-epanov_s/tabdata-stem-successors-20261111-r1')
S = R/'source-r1'
CONTROL_SOURCE = Path('/data2/lc-epanov_s/tabdata/runtime/architecture-execution-20261107-r1/source-gru-monitor-resume-r1/src')
P = '/tmp/tabdata-lc-epanov_s-architecture-20261107-env/bin/python'
CELLS = ('k64_s203301', 'gru512_k16_s203301', 'gru_dropout01_k16_s203301', 'k64_s203302', 'gru512_k16_s203302', 'gru_dropout01_k16_s203302')
GPU_BY_CELL = {'k64_s203301': 0, 'gru512_k16_s203301': 1, 'gru_dropout01_k16_s203301': 2, 'k64_s203302': 3, 'gru512_k16_s203302': 5, 'gru_dropout01_k16_s203302': 6}


def main() -> None:
    """Keep engineering work detached, finite, source-bound and disjoint by GPU."""
    sys.path.insert(0, str(CONTROL_SOURCE))
    from wnn.multistage_search import atomic_write_json, file_lock
    from wnn.multistage_search_owned_command import run_owned_command
    from wnn.multistage_search_runtime import current_process_owner, launch_detached_worker
    verify_source_capsule = runpy.run_path(str(S/'src/wnn/training/sequence_source_capsule.py'))['verify_source_capsule']

    parser = argparse.ArgumentParser()
    parser.add_argument('--detach', action='store_true')
    args = parser.parse_args()
    control = R/'control/root-profiles-r1'
    control.mkdir(parents=True, exist_ok=True)
    (R/'scratch').mkdir(exist_ok=True)
    if args.detach:
        print(json.dumps(launch_detached_worker([P,str(Path(__file__).resolve())],cwd=R,env=dict(os.environ),receipt_path=control/'owner.json',metadata={'profiles':6,'scientific_fits':0})))
        return
    with file_lock(control/'profile.lock',blocking=False):
        verify_source_capsule(S,S/'source-manifest.json','e2220d547dc92f791509e48762f164f70a3c064d01a4136156f8cc541dfb43d0','6b10dfe71fb0ebec9b0fc76788e2de0fd13d1dba')
        authority = json.loads((R/'inputs-r1/ROOT-profile-authority.json').read_text())
        assert authority['scientific_fits_admitted'] == 0 and authority['max_profiles'] == 6
        first = time.time()
        atomic_write_json(R/'receipts/first-profile-r1.json',{'first_profile_epoch':first,'campaign_first_gpu_epoch':1794359428.5272088,'fit_deadline_epoch':1794373828.5272088,'wave_deadline_epoch':1794377428.5272088},replace=False)
        owner = current_process_owner()

        def profile(item: tuple[int,str]) -> None:
            """Execute a single source/config-qualified profile, writing no scientific state."""
            gpu, cell = item
            config = R/'inputs-r1/configs'/f'{cell}.json'
            assert hashlib.sha256(config.read_bytes()).hexdigest() == authority['config_raw_sha256'][cell]
            output = R/'runs'/cell/'profile'
            assert not output.exists()
            env = dict(os.environ,PYTHONPATH=str(S/'src'),CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',NVIDIA_TF32_OVERRIDE='0',TORCH_ALLOW_TF32_CUBLAS_OVERRIDE='0',PYTHONDONTWRITEBYTECODE='1',WNN_MONITOR_HEARTBEAT_SECONDS='10',TMPDIR=str(R/'scratch'))
            for key in ('CUBLAS_WORKSPACE_CONFIG','CUBLAS_EMULATE_SINGLE_PRECISION','RANK','WORLD_SIZE','LOCAL_RANK'):
                env.pop(key,None)
            train = [P,str(S/'scripts/train_sequence.py'),'--config',str(config),'--data-root',str(R/'project'),'--split-manifest',str(R/'project/chronological_primary.json'),'--output',str(output),'--profile-updates','30']
            observed = '/data2/lc-epanov_s/tabdata/runtime/generalization-fix-20261108-r1/control/l4-wave-r1/observed_worker.py'
            bootstrap = 'import sys,runpy;sys.path.insert(0,'+repr(str(CONTROL_SOURCE))+');runpy.run_path('+repr(observed)+',run_name="__main__")'
            command = [P,'-c',bootstrap,'--',P,str(S/'scripts/observe_sequence.py'),'--output',str(output),'--interval','10','--max-seconds','290','--',*train]
            code, timed_out, _ = run_owned_command(command,cwd=S,env=env,log_path=control/f'{cell}.log',receipt_path=control/f'owned-{cell}.json',owner={'controller':owner,'cell_id':cell},stage=1,trial_number=gpu,mode='engineering_profile',gpu_key=str(gpu),output_dir=output,timeout_seconds=300)
            atomic_write_json(control/f'{cell}-result.json',{'exit_code':code,'timed_out':timed_out,'scientific_fits':0},replace=False)
            assert code == 0 and not timed_out, cell
            receipt = json.loads((output/'profile_receipt.json').read_text())
            assert receipt['status'] == 'profile_complete' and receipt['updates'] == 30 and receipt['errors'] == []
            assert receipt['identity']['source_sha256'] == '38d6dd71ec29fb8d23b9df801a448f23fb8b78c1e0832883dda1d6f25095643d'
            assert receipt['engineering_reload']['status'] == 'passed'
            print(json.dumps({'profile_complete':cell,'seconds':receipt['elapsed_seconds'],'peak_reserved_bytes':receipt['peak_reserved_bytes']}),flush=True)

        with ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(profile,((GPU_BY_CELL[cell],cell) for cell in CELLS)))
        atomic_write_json(control/'complete.json',{'profiles_passed':6,'scientific_fits':0,'time':time.time()},replace=False)


if __name__ == '__main__':
    main()
