"""Start one deadline-bounded final-readout watcher with child-only credentials."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(r"C:\Users\admin\Documents\Codex\artifacts\final-readout-watch-20261111")
PYTHON = Path(r"C:\Users\admin\Documents\Codex\reviews\galam-test-env-20261027\Scripts\python.exe")
WATCHER = ROOT / "final_readout_watch.py"
WATCHER_SHA = "9e6bc17d10dad55896dd5e7c917a168abc0acf512f897411ad7342a14513cfab"
GITHUB_HELPER = Path(r"C:\Users\admin\Documents\Codex\artifacts\architecture-execution-20261107\github_publish.py")
GITHUB_HELPER_SHA = "3b6774404e8b848740f89e9635773aab315dad3872c126c9df4af860460f8fe2"
LOG = ROOT / "final-readout-watch-r1.log"
OWNER = ROOT / "final-readout-watch-owner-r1.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def authorization() -> str:
    if sha(GITHUB_HELPER) != GITHUB_HELPER_SHA:
        raise RuntimeError("pinned GitHub credential helper changed")
    spec = importlib.util.spec_from_file_location("github_publish_final_readout", GITHUB_HELPER)
    if spec is None or spec.loader is None:
        raise RuntimeError("existing local Git credential helper is unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.authorization()


def main() -> None:
    if sha(WATCHER) != WATCHER_SHA:
        raise RuntimeError("final watcher bytes are not frozen to this launcher")
    if OWNER.exists() or LOG.exists():
        raise RuntimeError("final watcher already has an owner or log; refusing a duplicate")
    environment = dict(os.environ)
    environment.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
    for key in ("WNN_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"):
        environment.pop(key, None)
    environment["WNN_GITHUB_BASIC"] = authorization()
    command = [str(PYTHON), "-u", str(WATCHER), "--publish"]
    with LOG.open("xb") as log:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        environment.pop("WNN_GITHUB_BASIC", None)
        receipt = {
            "pid": process.pid,
            "started_epoch": time.time(),
            "watcher_sha256": WATCHER_SHA,
            "target_prs": [75, 80],
            "absolute_deadline_epoch": 1_794_377_428.5272088,
            "credential_in_child_environment": True,
            "scope": "read-only RPC summary collection and final comments on PR75/PR80; no SSH/GPU/training",
        }
        try:
            with OWNER.open("x", encoding="utf-8") as stream:
                json.dump(receipt, stream, sort_keys=True, indent=2)
                stream.write("\n")
        except OSError:
            process.terminate()
            process.wait(timeout=10)
            raise
    print(json.dumps({"pid": process.pid, "target_prs": [75, 80], "credential_persisted": False}))


if __name__ == "__main__":
    main()
