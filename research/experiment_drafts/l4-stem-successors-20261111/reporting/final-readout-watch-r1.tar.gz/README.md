# PR75 / PR80 final readout watcher

This local watcher reads the native terminal summaries through the existing
read-only RPC queues, verifies their pinned source, split, admission, fixed
endpoint, cell set, scorer coverage, and comparison receipts, then publishes one
idempotent final comment per PR. It watches PR75 QK normalization and PR80 L4
successors. PR74 R3 is intentionally outside this receiver.

The two native summary paths are:

- PR75: `/data/epanov_s/tabdata-qknorm-b300-20261111-r1/control/qknorm-receiver-r1/readout-complete.json`, plus the pinned `comparison-fourpair.json`.
- PR80: `/data/lc-epanov_s/tabdata-stem-successors-20261111-r1/control/readout-successors-r1/complete.json`.

The watcher uses the existing B300 and L4 RPC queue directories. It only queues
Python snippets that read these summary files. A disconnected transport leaves
the fetch pending; the report uses the last locally cached progress snapshot,
labels its age, and does not claim current fit or score state. At the original
epoch deadline `1794377428.5272088`, it publishes an explicit unverified partial
snapshot if no valid native summary was received. It never extends the clock.

No tests contact RPC or GitHub. The fixtures exercise exact PR75/PR80 summary
contracts, full-validation row coverage, and RPC response framing.

## Root launch command

After reviewing the pinned files and restoring the existing RPC transports,
ROOT can start the detached publisher with the pinned Python and credential-safe
launcher:

```powershell
$python = 'C:\Users\admin\Documents\Codex\reviews\galam-test-env-20261027\Scripts\python.exe'
& $python 'C:\Users\admin\Documents\Codex\artifacts\final-readout-watch-20261111\start_final_readout_watch_r1.py'
```

The launcher obtains the existing Semyon GitHub credential through the pinned
`github_publish.py` helper, passes it only to the child process, and records no
credential in its owner file or logs. The child is allowlisted to PR75 and PR80
and stops at the fixed deadline.
