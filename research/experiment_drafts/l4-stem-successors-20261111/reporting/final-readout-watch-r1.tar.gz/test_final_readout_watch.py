"""Focused fixtures for exact final-summary validation and RPC framing."""

from __future__ import annotations

import base64
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent))
import final_readout_watch as watch


def _score() -> dict[str, object]:
    return {"metric_id": "global_wp_clip2_v1", "selected_rows": 3_528_273, "t0": 0.61, "t1": 0.62, "wp": 0.615, "score": 0.615}


def _qk_cell(cell: str) -> dict[str, object]:
    return {
        "schema": "wnn.b300-qknorm-readout-cell.r1",
        "cell": cell,
        "status": "readout_complete",
        "checkpoint_sha256": "a" * 64,
        "prediction_manifest_sha256": "b" * 64,
        "score_sha256": "c" * 64,
        "score": _score(),
        "completed_epoch": 1_794_359_430.0,
        "owned_export": {"status": "completed"},
        "owned_score": {"status": "completed"},
    }


def _qk_summary() -> tuple[dict[str, object], dict[str, object]]:
    clock = json.loads((watch.ARTIFACTS / "b300-qknorm-20261111" / "native-profile-evidence-r1" / "receipts" / "clock-r2.json").read_text())
    comparison = {
        "schema": "wnn.b300-qknorm-fourpairs-comparison.r1",
        "status": "complete_exposed_fixed4E_screen",
        "source_sha256": watch.QK_SOURCE,
        "split_sha256": watch.QK_SPLIT,
        "mean_rms_minus_plain": 0.0002,
        "scores": {cell: _score() for cell in watch.QK_CELLS},
        "receipt_sha256": {
            cell: {
                "checkpoint_sha256": "a" * 64,
                "score_sha256": "b" * 64,
                "approved_profile_sha256": "c" * 64,
                "normalized_runtime_sha256": "d" * 64,
            }
            for cell in watch.QK_CELLS
        },
        "contrasts": [
            {"seed": seed, "candidate_wp": 0.62, "control_wp": 0.61, "rms_minus_plain": 0.01}
            for seed in (203301, 203302)
        ],
    }
    summary = {
        "schema": "wnn.b300-qknorm-readout-summary.r1",
        "status": "complete",
        "source_sha256": watch.QK_SOURCE,
        "authority_sha256": watch.QK_AUTHORITY,
        "split_sha256": watch.QK_SPLIT,
        "first_profile_epoch": clock["first_profile_epoch"],
        "fit_deadline_epoch": clock["fit_deadline_epoch"],
        "wave_deadline_epoch": watch.DEADLINE,
        "readouts": {cell: _qk_cell(cell) for cell in watch.QK_CELLS},
        "comparison": {"path": watch.TARGETS["pr75"]["comparison_path"], "sha256": "d" * 64},
    }
    return summary, comparison


def _l4_summary() -> dict[str, object]:
    cells: dict[str, object] = {}
    scores: dict[str, object] = {}
    for cell in watch.L4_CELLS:
        row = {
            "cell": cell,
            "status": "readout_complete",
            "source_sha256": watch.L4_SOURCE,
            "split_sha256": watch.L4_SPLIT,
            "model_sha256": "a" * 64,
            "config_sha256": "b" * 64,
            "data_sha256": "c" * 64,
            "prediction_manifest_sha256": "d" * 64,
            "score_receipt_sha256": "e" * 64,
            "fit_result_sha256": "f" * 64,
            "prediction_count": 1873,
            "scored_rows": 3_528_273,
            "prediction_shape": [20_000, 2],
            "prediction_dtype": "float32",
            "score": {**_score(), "within_tolerance": True},
        }
        cells[cell] = row
        scores[cell] = {"t0": 0.61, "t1": 0.62, "wp": 0.615, "selected_rows": 3_528_273}
    return {
        "schema": "wnn.l4-stem-successors-readout-summary.r1",
        "status": "complete",
        "source_sha256": watch.L4_SOURCE,
        "source_commit": "6b10dfe71fb0ebec9b0fc76788e2de0fd13d1dba",
        "source_manifest_sha256": watch.L4_MANIFEST,
        "config_manifest_sha256": watch.L4_CONFIG_MANIFEST,
        "split_sha256": watch.L4_SPLIT,
        "admission_sha256": watch.L4_ADMISSION,
        "fit_deadline_epoch": 1_794_373_828.5272088,
        "wave_deadline_epoch": watch.DEADLINE,
        "campaign_first_gpu_epoch": 1_794_359_428.5272088,
        "fixed_endpoint": {"epochs": 6, "global_updates": 38_760, "fit_sequences": 10_325, "evaluation_sequences": 1_873, "evaluation_selected_rows": 3_528_273, "metric_id": "global_wp_clip2_v1"},
        "cells": cells,
        "model_scores": scores,
        "reused_controls": {"status": "validated", "source_sha256": watch.L4_BASELINE_SOURCE, "receipts": watch.L4_BASELINE_RECEIPTS},
        "paired_contrasts": {
            "by_seed": [{"seed": seed} for seed in (203301, 203301, 203301, 203302, 203302, 203302)],
            "two_seed_mean": [{"arm": arm} for arm in ("k64", "gru512_k16", "gru_dropout01_k16")],
        },
    }


def test_qk_complete_requires_exact_four_full_valid_cells_and_comparison() -> None:
    summary, comparison = _qk_summary()
    assert watch.validate_qk(summary, comparison) == "complete"
    report = watch.format_report("pr75", summary, comparison, "complete", 1_794_360_000.0, None)
    assert "0.615000" in report and "descriptive screen only" in report
    summary["readouts"].pop(watch.QK_CELLS[-1])
    with pytest.raises(ValueError, match="exact four cells"):
        watch.validate_qk(summary, comparison)


def test_qk_wrong_selected_row_count_is_rejected() -> None:
    summary, comparison = _qk_summary()
    summary["readouts"][watch.QK_CELLS[0]]["score"]["selected_rows"] -= 1
    with pytest.raises(ValueError, match="full-valid"):
        watch.validate_qk(summary, comparison)


def test_frozen_producers_match_comparison_path_and_score_object_fixture() -> None:
    receiver = watch.ARTIFACTS / "b300-qknorm-20261111" / "receiving-r2" / "b300_qknorm_readout_r1.py"
    comparer = watch.ARTIFACTS / "b300-qknorm-20261111" / "receiving-r2" / "b300_qknorm_compare_r1.py"
    assert 'comparison_path = root / "comparison-fourpair.json"' in receiver.read_text(encoding="utf-8")
    assert '"scores": {cell: rows[cell]["score"]["score"]' in comparer.read_text(encoding="utf-8")
    assert watch.sha_file(watch.ARTIFACTS / "l4-stem-successors-20261111" / "ROOT-fit-admission-r1.json") == watch.L4_ADMISSION
    query = watch.rpc_code(watch.TARGETS["pr75"])
    assert watch.TARGETS["pr75"]["comparison_path"] in query
    compile(query, "<read-only-rpc-fixture>", "exec")
    summary, comparison = _qk_summary()
    for cell in watch.QK_CELLS:
        assert comparison["scores"][cell] == summary["readouts"][cell]["score"]


def test_qk_partial_summary_can_publish_only_validated_success_cells() -> None:
    summary, _comparison = _qk_summary()
    summary["status"] = "partial_or_failed"
    summary["comparison"] = None
    summary["readouts"][watch.QK_CELLS[-1]] = {"cell": watch.QK_CELLS[-1], "status": "readout_failed_or_partial"}
    assert watch.validate_qk(summary, None) == "partial_or_failed"


def test_qk_rpc_payload_hashes_exact_native_summary_and_comparison_bytes() -> None:
    summary, comparison = _qk_summary()
    comparison_raw = json.dumps(comparison, separators=(",", ":")).encode()
    summary["comparison"]["sha256"] = watch.sha_bytes(comparison_raw)
    summary_raw = json.dumps(summary, separators=(",", ":")).encode()
    files = {
        watch.TARGETS["pr75"]["summary"]: {"exists": True, "sha256": watch.sha_bytes(summary_raw), "size": len(summary_raw), "data_b64": base64.b64encode(summary_raw).decode()},
        watch.TARGETS["pr75"]["comparison"]: {"exists": True, "sha256": watch.sha_bytes(comparison_raw), "size": len(comparison_raw), "data_b64": base64.b64encode(comparison_raw).decode()},
    }
    got_summary, got_comparison, status = watch.verify_payload("pr75", watch.TARGETS["pr75"], files)
    assert status == "complete"
    assert got_summary["schema"] == summary["schema"]
    assert got_comparison["schema"] == comparison["schema"]
    files[watch.TARGETS["pr75"]["summary"]]["sha256"] = "0" * 64
    with pytest.raises(ValueError, match="byte hash"):
        watch.verify_payload("pr75", watch.TARGETS["pr75"], files)


def test_l4_complete_requires_six_exact_readouts_and_full_valid() -> None:
    summary = _l4_summary()
    assert watch.validate_l4(summary) == "complete"
    summary["cells"][watch.L4_CELLS[0]]["scored_rows"] -= 1
    with pytest.raises(ValueError, match="full-valid"):
        watch.validate_l4(summary)


def test_l4_missing_cell_cannot_claim_complete() -> None:
    summary = _l4_summary()
    summary["cells"].pop(watch.L4_CELLS[-1])
    with pytest.raises(ValueError, match="six full-valid"):
        watch.validate_l4(summary)


def test_rpc_result_requires_matching_success_envelope(tmp_path: Path) -> None:
    target = {"rpc": tmp_path}
    request_id = "r1"
    result_dir = tmp_path / "results"
    result_dir.mkdir()
    output = f"WNN_RPC_BEGIN {request_id}\n{{\"files\":{{}}}}\nWNN_RPC_END {request_id} ok\n"
    (result_dir / f"{request_id}.json").write_text(json.dumps({"id": request_id, "output": output}))
    assert watch.unpack_rpc(target, request_id) == {"files": {}}
    (result_dir / f"{request_id}.json").write_text(json.dumps({"id": request_id, "output": "WNN_RPC_END error"}))
    with pytest.raises(ValueError, match="exact successful"):
        watch.unpack_rpc(target, request_id)


def test_deadline_partial_snapshot_never_claims_a_model_score() -> None:
    report = watch.format_report("pr80", None, None, "unverified_at_deadline", None, "RPC transport unavailable")
    assert "No model score is claimed" in report
    assert "not a current native readout" in report
