"""Read and publish final, provenance-checked PR75/PR80 native readouts."""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import importlib.util
import json
import math
import os
import secrets
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ARTIFACTS = Path(r"C:\Users\admin\Documents\Codex\artifacts")
OUT = ARTIFACTS / "final-readout-watch-20261111"
CLIENT_PATH = Path(r"C:\Users\admin\Documents\Codex\reviews\WunderFunder-architecture-execution-20261107\scripts\sequence_progress_github.py")
CLIENT_SHA = "b9da652e028e5dd962df208221d7cbff80b9cc746b0a25944c23b19d870ae793"
HELPER75 = ARTIFACTS / "b300-qknorm-20261111" / "reporting-r1" / "publish_pr75_qknorm.py"
HELPER80 = ARTIFACTS / "l4-stem-successors-20261111" / "reporting" / "publish_l4_successors.py"
HELPER75_SHA = "d1339c32103bda4ea958b92eb2a2d74fa79479d3402aa6039869e02088299982"
HELPER80_SHA = "1c9fac8f04da78baaebde2c84c05a3367b881bd437f4bf1dee9ac711a44582fd"
QK_ADMISSION = "849b396a54c2e4ffbc5eeff572ddbcbb1921bdd019999fa951062ae28b815dc6"
QK_AUTHORITY = "b29dd5a08bdd75371808ce99c6b95730a864581b31b720cd6d52bae2b9f64837"
QK_SOURCE = "931a91046efb0f84e68184862e80076bb2751522bc6264fffa06e3cab36931fd"
QK_MANIFEST = "cb154b75d67fa63740be93264386644bcaab8f7f13952cb7e73935b49b612052"
QK_SPLIT = "0c4de3a253d23b3a5d5ca73b7aeb7fcae2b974673e4f9ec51e94e593c59d114c"
L4_ADMISSION = "07614e09393ab63b5b73cde50a045381512c682bc4bf93e9929daad25e4734b5"
L4_SOURCE = "38d6dd71ec29fb8d23b9df801a448f23fb8b78c1e0832883dda1d6f25095643d"
L4_MANIFEST = "e2220d547dc92f791509e48762f164f70a3c064d01a4136156f8cc541dfb43d0"
L4_CONFIG_MANIFEST = "2df8cba266f2ad5486e0b1de5370958666a915a6d22d45bfecd1e040af5ff6cf"
L4_BASELINE_SOURCE = "b9eddeb9a0733b8efa5a11bed24d03de53f94b83b03d72b5db09ab1adcd63188"
L4_BASELINE_RECEIPTS = {
    "k16_s203301": "842c0dc2606a62607d6f5c722bac7fcb09827e372537a4ab699d0c4c8642b75c",
    "k16_s203302": "eed8f1519dbc3b2e3e63a584d589bfca08d5a91094253e67efeb408af34ac8ff",
}
L4_SPLIT = QK_SPLIT
DEADLINE = 1_794_377_428.5272088
QK_CELLS = ("plain_s203301", "rms_s203301", "plain_s203302", "rms_s203302")
L4_CELLS = tuple(f"{arm}_s{seed}" for seed in (203301, 203302) for arm in ("k64", "gru512_k16", "gru_dropout01_k16"))
TARGETS = {
    "pr75": {
        "pr": 75,
        "rpc": ARTIFACTS / "b300-causal-stem-20261110" / "b300-rpc",
        "native": "/data/epanov_s/tabdata-qknorm-b300-20261111-r1/control/qknorm-receiver-r1",
        "summary": "readout-complete.json",
        "comparison": "comparison-fourpair.json",
        "comparison_path": "/data/epanov_s/tabdata-qknorm-b300-20261111-r1/comparison-fourpair.json",
        "cells": QK_CELLS,
    },
    "pr80": {
        "pr": 80,
        "rpc": ARTIFACTS / "l4-next70-20261110" / "l4-rpc",
        "native": "/data/lc-epanov_s/tabdata-stem-successors-20261111-r1/control/readout-successors-r1",
        "summary": "complete.json",
        "comparison": None,
        "cells": L4_CELLS,
    },
}
PROGRESS_STATES = {
    "pr75": ARTIFACTS / "b300-qknorm-20261111" / "reporting-r1" / "publisher-state-pr75-r1.json",
    "pr80": ARTIFACTS / "l4-stem-successors-20261111" / "reporting" / "publisher-state-pr80-r1.json",
}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def load_module(path: Path, name: str, expected: str) -> Any:
    if not path.is_file() or sha_file(path) != expected:
        raise ValueError(f"pinned local helper changed or missing: {path}")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot import pinned helper {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rpc_code(target: dict[str, Any]) -> str:
    paths = {target["summary"]: str(Path(target["native"]) / target["summary"])}
    if target["comparison"]:
        paths[target["comparison"]] = target["comparison_path"]
    return (
        "import base64,hashlib,json,pathlib,time\n"
        f"paths={paths!r}\n"
        "out={'observed_epoch':time.time(),'files':{}}\n"
        "for name,path in paths.items():\n"
        " p=pathlib.Path(path)\n"
        " if p.is_file() and p.stat().st_size<=12000000:\n"
        "  raw=p.read_bytes();out['files'][name]={'exists':True,'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw),'data_b64':base64.b64encode(raw).decode('ascii')}\n"
        " else: out['files'][name]={'exists':False}\n"
        "print(json.dumps(out,separators=(',',':')))\n"
    )


def enqueue(name: str, target: dict[str, Any], state: dict[str, Any]) -> None:
    rpc = target["rpc"]
    request_id = f"final-{name}-{int(time.time())}-{secrets.token_hex(4)}"
    request = {"code": rpc_code(target)}
    path = rpc / "requests" / f"{request_id}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(request), encoding="utf-8")
    os.replace(temporary, path)
    state["pending"] = request_id
    state["last_request_epoch"] = time.time()


def unpack_rpc(target: dict[str, Any], request_id: str) -> dict[str, Any] | None:
    path = target["rpc"] / "results" / f"{request_id}.json"
    if not path.is_file():
        return None
    wrapper = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(wrapper, dict):
        raise TypeError("RPC result wrapper is not an object")
    output = wrapper.get("output")
    begin, end = f"WNN_RPC_BEGIN {request_id}\n", f"WNN_RPC_END {request_id} ok"
    if not isinstance(output, str) or begin not in output or end not in output:
        raise ValueError("RPC response lacks the exact successful request envelope")
    payload = output.split(begin, 1)[1].split(end, 1)[0].strip()
    result = json.loads(payload)
    if not isinstance(result, dict) or not isinstance(result.get("files"), dict):
        raise TypeError("RPC response does not contain the expected files map")
    return result


def finite(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def is_sha256(value: object) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(char in "0123456789abcdef" for char in value.lower())


class PR75Adapter:
    """Adapt the pinned PR77 marker helper to the allowlisted PR75 client."""

    def __init__(self, client: Any) -> None:
        self.client = client

    def find_report(self, _pr: int, marker: str, prepared: float) -> Any:
        return self.client.find_report(75, marker, prepared)

    def post_report(self, _pr: int, body: str, *, before_post: Any) -> Any:
        return self.client.post_report(75, body, before_post=before_post)


def validate_qk(summary: dict[str, Any], comparison: dict[str, Any] | None) -> str:
    clock = json.loads((ARTIFACTS / "b300-qknorm-20261111" / "native-profile-evidence-r1" / "receipts" / "clock-r2.json").read_text(encoding="utf-8"))
    if (summary.get("schema") != "wnn.b300-qknorm-readout-summary.r1" or
        summary.get("source_sha256") != QK_SOURCE or summary.get("authority_sha256") != QK_AUTHORITY or
        summary.get("split_sha256") != QK_SPLIT or summary.get("wave_deadline_epoch") != DEADLINE or
        summary.get("fit_deadline_epoch") != clock["fit_deadline_epoch"] or
        summary.get("first_profile_epoch") != clock["first_profile_epoch"]):
        raise ValueError("PR75 readout summary ancestry or original clock differs")
    cells = summary.get("readouts")
    if not isinstance(cells, dict) or set(cells) != set(QK_CELLS):
        raise ValueError("PR75 summary does not enumerate the exact four cells")
    complete = True
    for cell, item in cells.items():
        if not isinstance(item, dict) or item.get("cell") != cell:
            raise ValueError(f"PR75 cell receipt malformed: {cell}")
        if item.get("status") != "readout_complete":
            complete = False
            continue
        score = item.get("score")
        if (item.get("schema") != "wnn.b300-qknorm-readout-cell.r1" or
            any(not is_sha256(item.get(key)) for key in ("checkpoint_sha256", "prediction_manifest_sha256", "score_sha256")) or
            not finite(item.get("completed_epoch")) or item["completed_epoch"] > DEADLINE or
            not isinstance(score, dict) or score.get("metric_id") != "global_wp_clip2_v1" or
            score.get("selected_rows") != 3_528_273 or not all(finite(score.get(k)) for k in ("t0", "t1", "wp")) or
            item.get("owned_export", {}).get("status") != "completed" or
            item.get("owned_score", {}).get("status") != "completed"):
            raise ValueError(f"PR75 full-valid score/provenance receipt invalid: {cell}")
    if summary.get("status") == "complete":
        if not complete or not isinstance(comparison, dict):
            raise ValueError("PR75 claims completion without four validated scores and comparison")
        contrasts = comparison.get("contrasts")
        scores = comparison.get("scores")
        receipts = comparison.get("receipt_sha256")
        if (comparison.get("schema") != "wnn.b300-qknorm-fourpairs-comparison.r1" or
            comparison.get("status") != "complete_exposed_fixed4E_screen" or
            comparison.get("source_sha256") != QK_SOURCE or comparison.get("split_sha256") != QK_SPLIT or
            not isinstance(scores, dict) or set(scores) != set(QK_CELLS) or
            not all(isinstance(value, dict) and value.get("metric_id") == "global_wp_clip2_v1" and
                    value.get("selected_rows") == 3_528_273 and
                    all(finite(value.get(key)) for key in ("t0", "t1", "wp")) for value in scores.values()) or
            not isinstance(receipts, dict) or set(receipts) != set(QK_CELLS) or
            not isinstance(contrasts, list) or len(contrasts) != 2 or
            not all(isinstance(row, dict) for row in contrasts) or
            {row.get("seed") for row in contrasts} != {203301, 203302} or
            not finite(comparison.get("mean_rms_minus_plain")) or
            any(not all(finite(row.get(k)) for k in ("candidate_wp", "control_wp", "rms_minus_plain")) for row in contrasts)):
            raise ValueError("PR75 four-pair comparison receipt is incomplete")
        for cell in QK_CELLS:
            score_hashes = receipts[cell]
            if (scores[cell] != cells[cell]["score"] or not isinstance(score_hashes, dict) or
                set(score_hashes) != {"checkpoint_sha256", "score_sha256", "approved_profile_sha256", "normalized_runtime_sha256"} or
                not all(is_sha256(value) for value in score_hashes.values())):
                raise ValueError(f"PR75 comparison score/receipt differs from cell readout: {cell}")
        return "complete"
    if summary.get("status") != "partial_or_failed":
        raise ValueError("PR75 summary has an unknown terminal status")
    return "partial_or_failed"


def validate_l4(summary: dict[str, Any]) -> str:
    if (summary.get("schema") != "wnn.l4-stem-successors-readout-summary.r1" or
        summary.get("source_sha256") != L4_SOURCE or
        summary.get("source_commit") != "6b10dfe71fb0ebec9b0fc76788e2de0fd13d1dba" or
        summary.get("source_manifest_sha256") != L4_MANIFEST or
        summary.get("config_manifest_sha256") != L4_CONFIG_MANIFEST or
        summary.get("split_sha256") != L4_SPLIT or
        summary.get("admission_sha256") != L4_ADMISSION or
        summary.get("fit_deadline_epoch") != 1_794_373_828.5272088 or
        summary.get("wave_deadline_epoch") != DEADLINE or
        summary.get("campaign_first_gpu_epoch") != 1_794_359_428.5272088 or
        summary.get("fixed_endpoint") != {"epochs": 6, "global_updates": 38760, "fit_sequences": 10325, "evaluation_sequences": 1873, "evaluation_selected_rows": 3528273, "metric_id": "global_wp_clip2_v1"}):
        raise ValueError("PR80 readout summary ancestry or fixed endpoint differs")
    cells, scores = summary.get("cells"), summary.get("model_scores")
    if (not isinstance(cells, dict) or set(cells) - set(L4_CELLS) or
        not all(isinstance(item, dict) for item in cells.values()) or
        not isinstance(scores, dict) or set(scores) - set(L4_CELLS) or
        not all(isinstance(item, dict) for item in scores.values())):
        raise ValueError("PR80 summary contains foreign/malformed cells")
    for cell, item in cells.items():
        if item.get("cell") != cell:
            raise ValueError(f"PR80 cell name mismatch: {cell}")
        if item.get("status") != "readout_complete":
            continue
        score = item.get("score")
        if (item.get("source_sha256") != L4_SOURCE or item.get("split_sha256") != L4_SPLIT or
            any(not is_sha256(item.get(key)) for key in ("model_sha256", "config_sha256", "data_sha256", "prediction_manifest_sha256", "score_receipt_sha256", "fit_result_sha256")) or
            item.get("prediction_count") != 1873 or item.get("scored_rows") != 3_528_273 or
            item.get("prediction_shape") != [20000, 2] or item.get("prediction_dtype") != "float32" or
            not isinstance(score, dict) or score.get("metric_id") != "global_wp_clip2_v1" or
            score.get("selected_rows") != 3_528_273 or score.get("within_tolerance") is not True or
            not all(finite(score.get(k)) for k in ("t0", "t1", "wp"))):
            raise ValueError(f"PR80 canonical full-valid receipt invalid: {cell}")
    if summary.get("status") == "complete":
        if set(cells) != set(L4_CELLS) or set(scores) != set(L4_CELLS) or any(cells[c].get("status") != "readout_complete" for c in L4_CELLS):
            raise ValueError("PR80 claims completion without six full-valid receipts")
        controls = summary.get("reused_controls", {})
        contrasts = summary.get("paired_contrasts")
        if not isinstance(controls, dict) or (contrasts is not None and not isinstance(contrasts, dict)):
            raise ValueError("PR80 reused-control or paired-contrast receipt is malformed")
        if contrasts is not None and (
            controls.get("status") != "validated" or
            controls.get("source_sha256") != L4_BASELINE_SOURCE or
            controls.get("receipts") != L4_BASELINE_RECEIPTS or
            len(contrasts.get("by_seed", [])) != 6 or
            len(contrasts.get("two_seed_mean", [])) != 3
        ):
            raise ValueError("PR80 paired contrasts lack the exact reused-control receipts")
        if any(not isinstance(scores[c], dict) or scores[c].get("selected_rows") != 3_528_273 or not all(finite(scores[c].get(k)) for k in ("t0", "t1", "wp")) for c in L4_CELLS):
            raise ValueError("PR80 model-score summary has incomplete full-valid metrics")
    elif summary.get("status") != "partial_or_failed":
        raise ValueError("PR80 summary has an unknown terminal status")
    return str(summary["status"])


def verify_payload(name: str, target: dict[str, Any], files: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None, str]:
    raw_summary, raw_comparison = [], None
    for file_name in (target["summary"], target["comparison"]):
        if file_name is None:
            continue
        receipt = files.get(file_name)
        if file_name == target["comparison"] and isinstance(receipt, dict) and receipt.get("exists") is not True:
            continue
        if not isinstance(receipt, dict) or receipt.get("exists") is not True:
            raise FileNotFoundError(f"native {name} summary not ready")
        raw = base64.b64decode(receipt["data_b64"], validate=True)
        if len(raw) != receipt.get("size") or sha_bytes(raw) != receipt.get("sha256"):
            raise ValueError(f"native {name} byte hash mismatch: {file_name}")
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise TypeError(f"native summary/comparison is not an object: {file_name}")
        if file_name == target["summary"]:
            raw_summary = value
        else:
            raw_comparison = value
    if name == "pr75":
        status = validate_qk(raw_summary, raw_comparison)
        nested = raw_summary.get("comparison")
        comparison_file = files.get(target["comparison"], {})
        if status == "complete" and (not isinstance(nested, dict) or nested.get("path") != TARGETS[name]["comparison_path"] or nested.get("sha256") != comparison_file.get("sha256")):
            raise ValueError("PR75 summary comparison hash does not match native comparison bytes")
    else:
        status = validate_l4(raw_summary)
    return raw_summary, raw_comparison, status


def cached_progress_observation(name: str) -> str | None:
    path = PROGRESS_STATES[name]
    if not path.is_file() or path.stat().st_size > 2_000_000:
        return None
    state = json.loads(path.read_text(encoding="utf-8"))
    reports = state.get("reports", {})
    rows = [row for row in reports.values() if isinstance(row, dict) and isinstance(row.get("body"), str) and finite(row.get("prepared_at"))]
    if not rows:
        return None
    latest = max(rows, key=lambda row: row["prepared_at"])
    body = latest["body"]
    first_lines = body.splitlines()[1:3]
    return " ".join(first_lines)[:400]


def revalidate_cached(name: str, item: dict[str, Any]) -> None:
    raw_b64 = item.get("summary_raw_b64")
    digest = item.get("summary_sha256")
    if not isinstance(raw_b64, str) or not isinstance(digest, str):
        raise TypeError("cached native summary bytes are missing")
    raw = base64.b64decode(raw_b64, validate=True)
    if sha_bytes(raw) != digest:
        raise ValueError("cached native summary hash changed")
    summary = json.loads(raw)
    if not isinstance(summary, dict):
        raise TypeError("cached native summary is not an object")
    comparison = None
    comparison_b64 = item.get("comparison_raw_b64")
    if comparison_b64 is not None:
        comparison_raw = base64.b64decode(comparison_b64, validate=True)
        if sha_bytes(comparison_raw) != item.get("comparison_sha256"):
            raise ValueError("cached comparison hash changed")
        comparison = json.loads(comparison_raw)
        if not isinstance(comparison, dict):
            raise TypeError("cached native comparison is not an object")
    status = validate_qk(summary, comparison) if name == "pr75" else validate_l4(summary)
    if status != item.get("status"):
        raise ValueError("cached terminal status differs from its verified summary")
    item["summary"], item["comparison"] = summary, comparison


def format_report(name: str, summary: dict[str, Any] | None, comparison: dict[str, Any] | None, status: str, verified_epoch: float | None, error: str | None) -> str:
    target = TARGETS[name]
    now = time.time()
    verified = "never" if verified_epoch is None else datetime.fromtimestamp(verified_epoch, UTC).isoformat(timespec="seconds")
    age = "unknown" if verified_epoch is None else f"{max(0, now - verified_epoch):.0f}s (stale observation age)"
    lines = [f"## Final canonical readout — PR{target['pr']}", f"Local publication snapshot: {datetime.fromtimestamp(now, UTC).isoformat(timespec='seconds')}; last successful RPC verification: {verified} ({age}).", f"Status: **{status}**."]
    if summary is None:
        lines.append(f"No native final summary was received and verified before the collection deadline. No model score is claimed. Latest fetch status: {error or 'summary unavailable'}.")
        cached = cached_progress_observation(name)
        if cached:
            lines.append(f"Last locally cached training-monitor note (historical snapshot only): {cached}. It is not a current native readout.")
    else:
        lines.extend([f"Native summary SHA-256: `{summary.get('_local_summary_sha256', 'hash unavailable')}`; native source `{summary.get('source_sha256')}`; official split `{summary.get('split_sha256')}`.", "The official validation partition has been repeatedly exposed as development evidence; these readouts are not independent validation or a public-score claim."])
        if name == "pr75":
            lines.append("Fixed-E4 QK-normalization four-cell readout (10,325 fitting sequences; full official validation 1,873 sequences / 3,528,273 selected rows):")
            for cell in QK_CELLS:
                row = summary.get("readouts", {}).get(cell, {})
                score = comparison["scores"][cell] if status == "complete" and comparison is not None else row.get("score", {})
                metrics = f"t0/t1/WP {score['t0']:.6f}/{score['t1']:.6f}/{score['wp']:.6f}" if row.get("status") == "readout_complete" else "score withheld"
                lines.append(f"- `{cell}`: {row.get('status', 'missing')}; {metrics}.")
            if status == "complete" and comparison is not None:
                lines.append(f"Paired RMS-minus-plain mean WP difference: {comparison['mean_rms_minus_plain']:+.6f} across two seeds; descriptive screen only.")
        else:
            lines.append("Fixed-E6 successor canonical readouts (10,325 fitting sequences; full official validation 1,873 sequences / 3,528,273 selected rows):")
            for cell in L4_CELLS:
                row = summary.get("cells", {}).get(cell, {})
                score = row.get("score", {})
                metrics = f"t0/t1/WP {score['t0']:.6f}/{score['t1']:.6f}/{score['wp']:.6f}" if row.get("status") == "readout_complete" else "score withheld"
                lines.append(f"- `{cell}`: {row.get('status', 'missing')}; {metrics}.")
            contrasts = summary.get("paired_contrasts")
            lines.append("Same-seed paired contrasts are included in the pinned native summary." if status == "complete" and contrasts else "Paired contrasts withheld; reused-control evidence was not complete or the readout was partial.")
    if error:
        lines.append(f"Latest transport/validation note: `{error[:240]}`. This note does not establish current native state.")
    marker_material = summary.get("_local_summary_sha256", "no-verified-summary") if summary else "no-verified-summary"
    marker = f"<!-- wnn-final-readout-{name}-{status}-{marker_material[:16]} -->"
    return "\n".join(lines) + "\n\n" + marker


def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(state, sort_keys=True, allow_nan=False), encoding="utf-8")
    os.replace(temp, path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish", action="store_true", help="use existing allowlisted GitHub client")
    parser.add_argument("--once", action="store_true", help="one local RPC poll only; no publication")
    parser.add_argument("--deadline", type=float, default=DEADLINE)
    args = parser.parse_args()
    if args.deadline != DEADLINE:
        raise ValueError("the frozen collection deadline cannot be extended")
    helper75 = load_module(HELPER75, "final_pr75_progress", HELPER75_SHA)
    if not HELPER80_SHA:
        raise RuntimeError("pin HELPER80_SHA from the frozen PR80 reporter before launch")
    helper80 = load_module(HELPER80, "final_pr80_progress", HELPER80_SHA)
    if sha_file(CLIENT_PATH) != CLIENT_SHA:
        raise ValueError("existing allowlisted GitHub client changed")
    state_path = OUT / "watch-state-r1.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.is_file() else {"schema": "wnn.final-readout-watch.r1", "targets": {}}
    done: set[str] = set(state.get("done", []))
    for name, item in state.get("targets", {}).items():
        if name in TARGETS and item.get("summary") is not None:
            try:
                revalidate_cached(name, item)
            except (OSError, ValueError, TypeError, KeyError, RuntimeError, UnicodeError, binascii.Error) as error:
                item.update(summary=None, comparison=None, status="cached_summary_unverified", last_error=f"{type(error).__name__}: {error}")
    while True:
        now = time.time()
        if now >= DEADLINE:
            for name in TARGETS:
                item = state.get("targets", {}).get(name, {})
                if name not in done and item.get("unverified_snapshot_posted"):
                    done.add(name)
            state["done"] = sorted(done)
            save_state(state_path, state)
            return 0 if len(done) == len(TARGETS) else 2
        for name, target in TARGETS.items():
            if name in done:
                continue
            item = state["targets"].setdefault(name, {"pending": None, "last_verified_epoch": None, "summary": None, "comparison": None, "summary_sha256": None, "last_error": None})
            if item["pending"] is None:
                if now - float(item.get("last_request_epoch", 0.0)) >= 45:
                    enqueue(name, target, item)
            else:
                try:
                    response = unpack_rpc(target, item["pending"])
                    if response is not None:
                        item["pending"] = None
                        item["last_rpc_epoch"] = now
                        files = response["files"]
                        if files.get(target["summary"], {}).get("exists"):
                            summary, comparison, status = verify_payload(name, target, files)
                            item.update(summary=summary, comparison=comparison, status=status,
                                        summary_sha256=files[target["summary"]]["sha256"],
                                        summary_raw_b64=files[target["summary"]]["data_b64"],
                                        comparison_sha256=files.get(target["comparison"], {}).get("sha256") if target["comparison"] else None,
                                        comparison_raw_b64=files.get(target["comparison"], {}).get("data_b64") if target["comparison"] else None,
                                        last_verified_epoch=now, last_error=None)
                        else:
                            item["status"] = "summary_not_yet_available"
                            item["last_error"] = "native final summary is not present at this read"
                except (OSError, ValueError, TypeError, KeyError, RuntimeError, UnicodeError, binascii.Error) as error:
                    item["pending"] = None
                    item["last_error"] = f"{type(error).__name__}: {error}"
            summary = item.get("summary")
            status = item.get("status", "waiting_for_native_summary")
            if summary is not None:
                summary["_local_summary_sha256"] = item["summary_sha256"]
                final = status in {"complete", "partial_or_failed"}
            else:
                final = DEADLINE - 60 <= now < DEADLINE
                status = "unverified_at_deadline" if final else status
            if final:
                body = format_report(name, summary, item.get("comparison"), status, item.get("last_verified_epoch"), item.get("last_error"))
                if args.publish:
                    marker = body.rsplit("\n", 1)[-1]
                    pub_state = OUT / f"publish-pr{target['pr']}-r1.json"
                    try:
                        spec = importlib.util.spec_from_file_location("sequence_progress_github_final", CLIENT_PATH)
                        if spec is None or spec.loader is None:
                            raise ImportError("cannot load allowlisted GitHub client")
                        client_mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(client_mod)
                        api_deadline = time.monotonic() + max(1.0, min(15.0, DEADLINE - time.time() - 5.0))
                        client = client_mod.ProgressGitHub({target["pr"]}, deadline=api_deadline)
                        if name == "pr75":
                            outcome = helper75.P.publish_once(PR75Adapter(client), pub_state, marker, body, now)
                        else:
                            outcome = helper80.publish_once(client, pub_state, target["pr"], marker, body, now)
                        item["publish_outcome"] = outcome
                        if outcome in {"posted", "reconciled-existing", "already-posted"}:
                            item["last_publish_error"] = None
                            if summary is not None:
                                done.add(name)
                            else:
                                item["unverified_snapshot_posted"] = True
                    except (OSError, ValueError, TypeError, RuntimeError, TimeoutError, ImportError) as error:
                        item["last_publish_error"] = f"{type(error).__name__}: {error}"
                else:
                    print(body)
                    done.add(name)
        state["done"] = sorted(done)
        state["updated_epoch"] = time.time()
        save_state(state_path, state)
        if args.once or len(done) == len(TARGETS):
            return 0 if len(done) == len(TARGETS) or not args.publish else 2
        time.sleep(15)


if __name__ == "__main__":
    raise SystemExit(main())
